class Collectible(object):
    def __init__(self, d, c, v):
        self.description = d
        self.condition = c
        self.value = v


def collectible_printer(collectibles):
    output_string = ""
    total = 0
    for item in collectibles:
        total += item.value
        output_string += "\nthe item is " + item.description
        output_string += " and it's in " + item.condition + " shape."
        output_string += " It has the value " + str(item.value)
        output_string += " and the total is " + str(total)
    return output_string


collectible1 = Collectible("a toy lightsaber", "mint", 100)
collectible2 = Collectible("a boba fett figurine", "very bad", 300)
collectible3 = Collectible("an R2D2 toy", "very good", 30)
collectibless = [collectible1, collectible2, collectible3]
print(collectible_printer(collectibless))
# Maeghan helped with PEP8 errors
