def introduction(p_name):
    print("Hello! My name is " + p_name)


def favorite_numbers(a, b, c):
    print("Your favorite numbers are " + str(a) + ", " + str(b) + ", " + "and " + str(c))


name = input("What is your name?")
introduction(name)


number1 = input("What your favorite number?")
number2 = input("What your second favorite number?")
number3 = input("What your third favorite number?")

favorite_numbers(number1, number2, number3)

# Megan helped me put my variables ouside the funtion
