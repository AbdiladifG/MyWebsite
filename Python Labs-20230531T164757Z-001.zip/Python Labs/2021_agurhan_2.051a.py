prizes = ["piece of paper", "house", "pet bird", "spaceship"]
index = input("Give me a number from 1 - 4")
index = int(index)
print(prizes[index - 1])
# Megan helped me make index an integer
