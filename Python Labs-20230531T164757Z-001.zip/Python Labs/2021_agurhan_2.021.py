diameter = float(input("Give me the diameter of a circle."))
# 1.7
# 1
# c = 3.14
circumference = (diameter * 3.1415926535)
print(circumference)
circumference = int(diameter * 3.14)
print(circumference)
# Megan helped me with PEP8 errors
