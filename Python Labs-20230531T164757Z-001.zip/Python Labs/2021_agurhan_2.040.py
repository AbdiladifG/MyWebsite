prize1 = "piece of paper"
prize2 = "house"
prize3 = "pet bird"
prize4 = "spaceship"
number = input("Give me a number from 1 to 4.")
if number == "1":
    print("You won a " + prize1 + "!!!")
elif number == "2":
    print("You won a " + prize2 + "!!!")
elif number == "3":
    print("You won a " + prize3 + "!!!")
elif number == "4":
    print("You won a " + prize4 + "!!!")
else:
    print("You didn't win anything.")
# Simon helped me pick prizes
