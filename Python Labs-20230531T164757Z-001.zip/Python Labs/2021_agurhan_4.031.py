def loop1():
    row = ""
    for i in range(6):
        row += "* "
    print(row)


def loop2():
    row = ""
    for i in range(4, 13):
        row = row + str(i) + " "
    print(row)


def loop3():
    row = ""
    for i in range(1, 12):
        if i % 2 == 0:
            row = row + "* "
        else:
            row = row + str(i) + " "
    print(row)


def loop4():
    for j in range(6):
        row = ""
        for i in range(6):
            row = row + "* "
        print(row)


def loop5():
    for j in range(6):
        row = ""
        for i in range(6):
            row = row + str(i + 2) + " "
        print(row)


def loop6():
    for j in range(6):
        row = ""
        for i in range(6):
            row = row + str(j + 1) + "-" + str(i + 1) + " "
        print(row)


def loop7():
    counter = 1
    for j in range(6):
        row = ""
        for i in range(counter):
            row = row + str(i + 1) + " "
        counter += 1
        print(row)


def loop8():
    counter = 1
    for j in range(6):
        row = ""
        for i in range(counter):
            if i % 2 == 0:
                row = row + str("*") + " "
            else:
                row = row + str(i + 1) + " "
        counter += 1
        print(row)


print(loop1())
print(loop2())
print(loop3())
print(loop4())
print(loop5())
print(loop6())
print(loop7())
print(loop8())

# Maeghan helped with PEP8 errors
