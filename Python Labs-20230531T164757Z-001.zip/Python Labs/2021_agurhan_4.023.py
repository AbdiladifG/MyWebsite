def playlist_1(p_list):
    new_list = []
    for x in p_list:
        new_list.append(x)
    return new_list


def playlist_2(p_list2):
    new_list2 = []
    counter = 2
    while counter < len(p_list2):
        new_list2.append(p_list2[counter])
        counter += 1
    return new_list2


def playlist_3(p_list3):
    new_list3 = []
    counter = 2
    while counter < len(p_list3) - 2:
        new_list3.append(p_list3[counter])
        counter += 1
    return new_list3


def playlist_4(p_list4):
    new_list4 = []
    counter = 0
    while counter < len(p_list4):
        if counter % 3 == 0:
            new_list4.append(p_list4[counter])
        counter += 1
    return new_list4


def playlist_5(p_list5):
    new_list5 = []
    counter = 1
    while counter < len(p_list5):
        if counter % 2 == 1:
            new_list5.append(p_list5[counter])
        counter += 1
    return new_list5


list1 = ["other people's pets", "end of scarcity", "other side", "die waiting", "seven hours with a backseat driver"]
print(playlist_1(list1))

list2 = ["other people's pets", "end of scarcity", "other side", "die waiting", "seven hours with a backseat driver"]
print(playlist_2(list2))

list3 = ["other people's pets", "end of scarcity", "other side", "die waiting", "seven hours with a backseat driver"]
print(playlist_3(list3))

list4 = ["other people's pets", "end of scarcity", "other side", "die waiting", "seven hours with a backseat driver"]
print(playlist_4(list4))

list5 = ["other people's pets", "end of scarcity", "other side", "die waiting", "seven hours with a backseat driver"]
print(playlist_5(list5))

# Maeghan helped with syntax
