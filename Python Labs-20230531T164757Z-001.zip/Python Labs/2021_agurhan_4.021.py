def the_rock_says(p_list):
    p_newlist = []
    for item in p_list:
        if item[0] == 's' and item[1] == 'm':
            message1 = ("Do you smell what The Rock is cooking")
            p_newlist.append(message1)
        elif item[-5:] == "think":
            message2 = ("It doesn't matter what you think")
            p_newlist.append(message2)
        elif item:
            message3 = ("The Rock says " + item)
            p_newlist.append(message3)
    return p_newlist


list1 = ['eggs', 'apple', 'smash', 'what do you think']
 

print(the_rock_says(list1))
print(the_rock_says(list1))
print(the_rock_says(list1))

# Maeghan helped with PEP8 errors
