yuka = input("Are you Yuka Kinoshita?")
stomach = int(input("What is your stomach size?"))
money = int(input("How much money do you have?"))
print((yuka == "yes" or stomach > 100) and money > 50)
# Megan helped with PEP8 errors
