universe = input("Is she Marvel or DC")
age = input("How old is she?")
power = input("What is her power?")
age = int(age)
power = int(power)
print(universe == "DC" and age <= 18 and power > 100)
# Megan helped me figure out what questions to ask
