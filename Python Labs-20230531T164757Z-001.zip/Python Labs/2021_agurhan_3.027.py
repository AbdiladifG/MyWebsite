def longest_reception(p_numbers):
    max_reception = p_numbers[0]
    for number in p_numbers:
        if number > max_reception:
            max_reception = number
    return max_reception


numbers = [100, 3, 20, 18, 223]
max_reception = longest_reception(numbers)
print("The minimum is " + str(max_reception))
# Megan helped me with PEP8 errors
