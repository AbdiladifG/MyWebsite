def add(p_dict, p_type, p_name):
    if p_type in p_dict:
        p_dict[p_type].append(p_name)
    else:
        p_dict[p_type] = [p_name]
    return p_dict


def get(p_dict, p_type):
    if p_type in p_dict:
        return ("Mr. McGlathery owns these " + p_type + " pokemons:" + str(p_dict[p_type]))
    else:
        return "Mr. Glathery does not have this in his collection."


poke_dict = {}
while poke_dict != "quit":
    addorget = input("Do you want to add a Pokemon or Get type of Pokemon?")
    if addorget == "add":
        poke_type = input("Gimme the type")
        poke_name = input("Gimme the name")
        print(add(poke_dict, poke_type, poke_name))
    if addorget == "get":
        get_type = input("What is the type of the pokemon you want to get?")
        print(get(poke_dict, get_type))
# Maeghan helped me add the poke_dict != "quit": part
