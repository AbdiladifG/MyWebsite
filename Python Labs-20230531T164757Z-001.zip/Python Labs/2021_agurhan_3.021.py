def sorting_hat():
    import random
    houses = ["Gryffindor", "Hufflepuff", "Slytherin", "Ravenclaw", "Pufflehuff", "Ruffletuff", "Wufflehuff"]
    ignore = input("What house do you like the most?")
    house = random.randint(0, 6)
    return (houses[house])
    print(sorting_hat())


print(sorting_hat())
# Megan helped with PEP8 errors
