def lilo_hacks(p_text, trueorfalse):
    altered_text = ""
    if trueorfalse is True:
        return ""
    else:
        counter = 0
        for letter in p_text:
            if counter % 2 == 1:
                altered_text += letter
            counter += 1
    return altered_text


message = lilo_hacks('capture lilo and stitch now', True)
print("The message after Lilo hacked it is this: " + str(message))
message = lilo_hacks('capture lilo and stitch now', False)
print("The message after Lilo hacked it is this: " + str(message))

# Megan helped me with the function
