def dr_lam_workout_counter(exercises):
    return_dict = {}
    for exercise in exercises:
        if exercise in return_dict.keys():
            return_dict[exercise] = return_dict[exercise] + 1
        else:
            return_dict[exercise] = 1
    return return_dict


monday_exercises = ['Bench press', 'sprint', 'sprint', 'squat', 'squat', 'sprint', 'situps', 'sprint', 'squat']
wednesday_exercises = ['sprint', 'sprint', 'sprint', 'squat', 'squat', 'sprint', 'situps', 'sprint', 'squat']
friday_exercises = ['biceps', 'biceps', 'biceps', 'situps', 'sprint', 'squat', 'biceps', 'biceps']
workout_counter1 = dr_lam_workout_counter(monday_exercises)
workout_counter2 = dr_lam_workout_counter(wednesday_exercises)
workout_counter3 = dr_lam_workout_counter(friday_exercises)
print(workout_counter1)
print(workout_counter2)
print(workout_counter3)
# Maeghan helped with PEP8 errors
