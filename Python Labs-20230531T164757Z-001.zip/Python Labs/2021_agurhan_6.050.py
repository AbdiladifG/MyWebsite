def homework_times():
    """
    Creates some test data for this program.  Assumes 50 page of homework.
    Each homework takes between 1-20 minutes to complete
    :return: Returns a dictionary.  Key is the page of homework.  value is how long it takes to do that page (mins)
    """
    import random
    homework_dictionary = {}
    for i in range(50):
        homework_dictionary[i] = random.randint(1, 20)
    return homework_dictionary
    

def split_dict_to_multiple(input_dict, friends):
    """Splits dict into multiple dicts with given maximum size.
    Returns a list of dictionaries."""
    import copy
    import math
    max_limit = math.ceil(50 / friends)
    chunks = []
    curr_dict = {}
    for k, v in input_dict.items():
        if len(curr_dict.keys()) < max_limit:
            curr_dict.update({k: v})
        else:
            chunks.append(copy.deepcopy(curr_dict))
            curr_dict = {k: v}
    # update last curr_dict
    chunks.append(curr_dict)
    return chunks


def honest_johnny_time(p_dict):
    sum = 0
    for key in p_dict.keys():
        times = p_dict[key]
        sum += times
    return sum


def cheating_johnny_time(dictionaries):
    max = -99999999999
    for dict in dictionaries:
        this_dictionary_time = honest_johnny_time(dict)
        if this_dictionary_time > max:
            max = this_dictionary_time
    total_time = 100 + max
    return total_time


times = homework_times()
total = honest_johnny_time(times)
split_times = split_dict_to_multiple(times, 2)
split_times5 = split_dict_to_multiple(times, 5)
split_times25 = split_dict_to_multiple(times, 25)
speedup_time = (cheating_johnny_time(split_times))
speedup_time5 = (cheating_johnny_time(split_times5))
speedup_time25 = (cheating_johnny_time(split_times25))
print("The speedup for 2 friends is " + str(speedup_time))
print("The speedup for 5 friends is " + str(speedup_time5))
print("The speedup for 25 friends is " + str(speedup_time25))
# Maeghan helped with PEP8 errors
