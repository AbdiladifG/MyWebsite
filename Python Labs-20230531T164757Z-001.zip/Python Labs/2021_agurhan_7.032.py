class Flaherty(object):
    def __init__(self, p_name, p_wallet_value):
        self.name = p_name
        self.wallet_value = p_wallet_value
        self.possessions = []

    def earn(self):
        self.wallet_value += 30000

    def buy(self, p_item, p_cost):
        self.possessions.append(p_item)
        self.wallet_value -= int(p_cost)

    def tweet(self):
        tweet_string = "My name is " + self.name
        tweet_string += " Flaherty and I have " + str(self.possessions)
        return tweet_string


ned = Flaherty('Ned', 3000)
jack = Flaherty('Jack', 1000)
ned.earn()
ned.buy('lightsaber', 1000)
print(ned.tweet())
# Maeghan helped with calling the methods
