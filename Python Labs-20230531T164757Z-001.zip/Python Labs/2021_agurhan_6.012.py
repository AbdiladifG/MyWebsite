def course_numbers(p_dictionary, p_input):
    if p_input in p_dictionary.keys():
        return (p_dictionary[p_input])
    else:
        return "This course does not exist."


course_name = input("What's the name of the course you're looking for?")
dictionary = {'CS2': 'T527', 'CyberSec 2': 'T746', 'IT2': 'T746', 'McG': 'M416', 'AP Comp Sci': 'M416', 'AP CS': 'M416'}
print(course_numbers(dictionary, course_name))
# Maeghan helped make the second input parameter
