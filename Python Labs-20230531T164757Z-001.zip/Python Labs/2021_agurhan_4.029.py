def point_result(win_point_percentage):
    import random
    number = random.randint(1, 100)
    if number <= win_point_percentage:
        return True
    else:
        return False


def bout_result(p_win_point_percentage):
    fencer = 0
    opponent = 0
    for winner in range(9):
        result = point_result(p_win_point_percentage)
        if result is True:
            fencer += 1
        elif result is False:
            opponent += 1
        if fencer == 5:
            break
        elif opponent == 5:
            break
    return [fencer, opponent]


def match_result(p_win_point_percentage_1, p_win_point_percentage_2, p_win_point_percentage_3):
    brisk_team = 0
    opponent_team = 0
    for winner in range(100):
        if brisk_team >= 45 or opponent_team >= 45:
            break
        result = bout_result(p_win_point_percentage_1)
        brisk_team += result[0]
        opponent_team += result[1]

        if brisk_team >= 45 or opponent_team >= 45:
            break
        result = bout_result(p_win_point_percentage_2)
        brisk_team += result[0]
        opponent_team += result[1]
        if brisk_team >= 45 or opponent_team >= 45:
            break
        result = bout_result(p_win_point_percentage_3)
        brisk_team += result[0]
        opponent_team += result[1]
    if brisk_team >= opponent_team:
        print("woawh! ", brisk_team, opponent_team)
        return True
    else:
        print("food! ", brisk_team, opponent_team)
        return False


def career_mode(p_win_point_percentage_1, p_win_point_percentage_2, p_win_point_percentage_3, p_matches):
    wins = 0
    losses = 0
    for i in range(p_matches):
        result = match_result(p_win_point_percentage_1, p_win_point_percentage_2, p_win_point_percentage_3)
        if result is True:
            wins += 1
        else:
            losses += 1
    return wins / p_matches


win_pct_1 = input("HellO! Give me the point winning percentage of fencer #1 on Ms. Brisk's team")
win_pct_2 = input("HellO! Give me the point winning percentage of fencer #2 on Ms. Brisk's team")
win_pct_3 = input("HellO! Give me the point winning percentage of fencer #3 on Ms. Brisk's team")
matches = input("How many matches do you want this team to play?")

print("Ms. Brisk's career winning percentage with this team  is this:")
print(career_mode(int(win_pct_1), int(win_pct_2), int(win_pct_3), int(matches)))
# Maeghan helped with PEP8 errors
