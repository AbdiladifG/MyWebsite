def item_list_to_dictionary(items_sold):
    items_sold_dict = {}
    for item in items_sold:
        if item in items_sold_dict.keys():
            items_sold_dict[item] = items_sold_dict[item] + 1
        else:
            items_sold_dict[item] = 1
    return items_sold_dict
    

def min_item(items_sold_dict):
    print(items_sold_dict)
    min_number = 100000000
    min_number_key = 'key'
    for key in items_sold_dict.keys():
        if items_sold_dict[key] < min_number:
            min_number = items_sold_dict[key]
            min_number_key = key
    return min_number_key


sold_items = ['m', 'c',  'n', 'm', 'c', 'n',  'c', 't', 'g', 'e', 'n', 's', 'g', 'm', 'e', 's']

sold_item_numbers = item_list_to_dictionary(sold_items)
print("BLAHBLAH " + str(sold_item_numbers))
min_key = min_item(sold_item_numbers)
print(min_key)
sold_item_numbers = item_list_to_dictionary(sold_items)
print("BLAHBLAH " + str(sold_item_numbers))
min_key = min_item(sold_item_numbers)
print(min_key)
sold_item_numbers = item_list_to_dictionary(sold_items)
print("BLAHBLAH " + str(sold_item_numbers))
min_key = min_item(sold_item_numbers)
print(min_key)
sold_item_numbers = item_list_to_dictionary(sold_items)
print("BLAHBLAH " + str(sold_item_numbers))
min_key = min_item(sold_item_numbers)
print(min_key)
sold_item_numbers = item_list_to_dictionary(sold_items)
print("BLAHBLAH " + str(sold_item_numbers))
min_key = min_item(sold_item_numbers)
print(min_key)
del sold_item_numbers['t']
print(sold_item_numbers)
# Maeghan helped me find del
