public class CountingZeros
{
    /*
     * returns the number of zeros in myArray
     */
    public static int countZeros(int[] myArray)
    {
        int counter = 0;
        for(int i = 0; i < myArray.length; i++)
        {
            if (myArray[i] == 0)
            {
                counter += 1;
            }
        }
        return counter; // add some lines of code above this and change this line
    }

    public static void main(String[] args)
    {
        // declare and initialize an array of ints
        int[] fred = { 2, 4, 0, 1, 6, 0, 0, 6, 0 };
        // ask countZeros to tell us how many zeros there are
        int result = countZeros(fred);
        System.out.println(result);
    }

}