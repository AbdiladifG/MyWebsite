public class Point
{
    private int x;
    private int y;
    
    public Point (int a, int b)
    {
        x = a;
        y = b;
    }
    
    public Point (String s)
    {
        // "(321, 4)"
        int comma = s.indexOf(",");
        x = Integer.parseInt(s.substring(1, comma));
        y = Integer.parseInt(s.substring(comma + 2, s.length() - 1));
    }
    
    public int getX() // "getter method"
    {
        return x;
    }
    
    public int getY()
    {
        return y;
    }
    
    public void setX(int a) // "setter method"
    {
        x = a;
    }
    
    public void translate(int dx, int dy)
    {
        x += dx;
        y = y + dy;
    }
    
    public void invert()
    {
        int temp = y;
        y = x;
        x = temp;
    }
    
    public String toString()
    {
        // "(x, y)"
        return "(" + x + ", " + y + ")";
    }
    
}