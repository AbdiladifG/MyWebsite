public class PointMain
{

    public static void main(String[] args)
    {
        Point fred = new Point(3, 5);
        Point wilma = new Point("(-2, 7)");
        System.out.println(wilma);
        wilma.setX(10);
        System.out.println(wilma.getX());
//        System.out.println(fred.y);
        System.out.println("Initially: " + fred);
        fred.translate(4, 1);
        fred.invert();
        System.out.println("Finally: " + fred);
    }

}