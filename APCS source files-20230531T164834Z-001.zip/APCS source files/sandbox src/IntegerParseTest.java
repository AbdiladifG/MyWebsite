public class IntegerParseTest
{

	public static void main(String[] args)
	{
		String fred = "2022";
		int wilma = Integer.parseInt(fred);
		
		fred = fred + 4;
		wilma = wilma + 4;
		
		System.out.println("This is fred: " + fred);
		System.out.println("This is wilma: " + wilma);
	}

}