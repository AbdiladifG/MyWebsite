import java.util.Scanner;

// enter 4 numbers, output the smallest and the sum
public class FindMin
{

    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.println("Enter 4 numbers and I will tell you the min and the sum.");
        int min = Integer.MAX_VALUE;
        int sum = 0;
        for(int i = 0; i < 4; i ++)
        {
            System.out.print("Enter number "+ (i + 1) + ": ");
            int input = console.nextInt();
            if (input < min)
            {
                min = input;
            }
            sum += input;
        }
        System.out.println("The min value is: " + min);
        System.out.println("The sum is: " + sum);
    }

}
