import java.util.Arrays;

public class ArrayPractice
{

    public static void main(String[] args)
    {
        int[] numbers = new int[30];
        for(int i = 0; i < numbers.length; i++)
        {
            numbers[i] = 10;
        }
        
        for(int i = 1; i < numbers.length; i++)
        {
            numbers[i] += numbers[i - 1];
        }
        
        
        System.out.println(Arrays.toString(numbers));

    }

}
