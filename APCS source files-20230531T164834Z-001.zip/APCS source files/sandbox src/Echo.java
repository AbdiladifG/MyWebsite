import java.util.Scanner;

public class Echo
{

    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.println("Type something");
        String expression = console.nextLine();
        while (!expression.equals("done"))
        {
            System.out.println("Echo: " + expression);
            System.out.println("Type something");
            expression = console.nextLine();
        }
        System.out.println("Bye!");
    }

}
