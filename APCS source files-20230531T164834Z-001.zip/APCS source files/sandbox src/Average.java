import java.util.Scanner;

public class Average
{

    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.print("Enter a number");
        int num1 = console.nextInt();

        System.out.print("Enter a number");
        int num2 = console.nextInt();

        System.out.print("Enter a number");
        int num3 = console.nextInt();

        System.out.print("Enter a number");
        int num4 = console.nextInt();

        System.out.print("Enter a number");
        int num5 = console.nextInt();
        
        int total = num1 + num2 + num3 + num4 + num5;
        int avg = total / 5;
        System.out.println(avg);

    }

}
