import java.util.Scanner;

public class IsImproper
{
    /**
     * 
     * @param fraction: a String representing a fraction in the form a/b
     * @return: true of a > b, otherwise false
     */
    public static boolean isImproper(String fraction)
    {
        int slash = fraction.indexOf('/');
        int num = Integer.parseInt(fraction.substring(0, slash));
        int den = Integer.parseInt(fraction.substring(slash + 1));
        return num > den;
        
    }
    
    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        
        String firstFraction = "4/10";
        String secondFraction = "10/4";
        System.out.println(firstFraction + " is improper: " + isImproper(firstFraction));
        System.out.println(secondFraction + " is improper: " + isImproper(secondFraction));
        
        System.out.print("Enter a fraction in the form a/b: ");
        String fraction = console.nextLine();
        if (isImproper(fraction))
        {
            System.out.println("That is an improper fraction");
        }
        else
        {
            System.out.println("That is not an improper fraction");
        }
    }



}