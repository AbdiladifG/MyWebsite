public class GreatestCommonFactor
{
    public static int gcf(int num1, int num2)
    {
        int greatestSoFar = 1;
        for (int f = 2; f <= num1; f++)
        {
            if (num1 % f == 0 && num2 % f == 0) // replace false to fix
            {
                greatestSoFar = f; // replace 0 to fix
            }
        }
        return greatestSoFar;
    }
    
    public static void main(String[] args)
    {
        int first = 54;
        int second = 24;
        int result = gcf(first, second);
        System.out.println("The result is: " + result);
    }

}