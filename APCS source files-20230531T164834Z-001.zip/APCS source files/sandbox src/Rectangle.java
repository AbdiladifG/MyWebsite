
public class Rectangle
{

    public static void main(String[] args)
    {
        for(int row = 0; row < 6; row++)
        {
            for(int col = 0; col < 6; col++)
            {
                System.out.print("*");
            }
            System.out.println("");
        }

    }

}
