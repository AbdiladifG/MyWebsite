
public class Coins
{

    public static void main(String[] args)
    {
        int pennies = 6;
        int nickels = 3;
        int dimes = 4;
        int quarters = 2;
        double total = (pennies * .01 + nickels * .05 + dimes * .1 + quarters * .25);
        System.out.println(total);        

    }

}
