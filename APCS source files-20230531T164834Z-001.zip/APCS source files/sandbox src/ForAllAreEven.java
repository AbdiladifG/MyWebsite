public class ForAllAreEven
{
    public static boolean allAreEven(int[] myArray)
    {
        int counter = 0;
        for (int i = 0; i < myArray.length; i++)
        {
            if (myArray[i] % 2 == 1)
            {
                counter += 1;
            }
        }
        
        if (counter == 0)
        {
            return true;
        }
        
        else
        {
            return false;
        }
    }

    
    public static void main(String[] args)
    {
        int[] test1 = { 2, 3, 4, 5, 6, 7, 8 };
        int[] test2 = { 10, 20, 2, 6, 72, 6, 18 };
        System.out.println(allAreEven(test1));
        System.out.println(allAreEven(test2));
    }

}