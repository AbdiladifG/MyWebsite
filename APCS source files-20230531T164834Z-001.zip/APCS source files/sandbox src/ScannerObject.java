import java.util.*;

public class ScannerObject
{

    public static void main(String[] args)
    {
        
        Scanner console = new Scanner(System.in);
        System.out.print("Gimme a number");
        int number = console.nextInt () ;
        for(int i = 0; i < number; i++)
        {
            System.out.println("I'm feeling loopy");
        }

    }

}
