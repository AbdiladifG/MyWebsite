
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EightBall extends JFrame implements ActionListener
{
    // Change this to a button, since we will be changing the title of the
    // button
    private JButton message;

    public static void main(String[] args)
    {
        EightBall ab = new EightBall();
        ab.display();
    }

    public EightBall()
    {
        // No layout required, we are completely filling the frame with the one
        // button
        setLayout(new BorderLayout());

        // This initializes the instance variable, which is a button not a label
        // The button should start with the text "Ask a question"
        // You'll also need to do the addActionListener(this) with the button
        message = new JButton("Ask a question");
        message.addActionListener(this);
        // Just add the button - no layout to include here
        add(message);

        // Don't need anything from here down to setTitle, because we just have
        // the one button in the frame

        // Give the window an appropriate name
        setTitle("Eight Ball");
        setSize(400, 200);
    }

    public void display()
    {
        setVisible(true);
    }

    // You're welcome - these are the official 8-Ball messages - feel free to
    // remove/add your own
    private String randomResponse()
    {
        String[] responses = { "It is certain", "It is decidedly so", "Without a doubt", "Yes definitely",
                "You may rely on it", "As I see it, yes", "Most likely", "Outlook good", "Yes", "Signs point to yes",
                "Reply hazy, try again", "Ask again later", "Better not tell you now", "Cannot predict now",
                "Concentrate and ask again", "Don't count on it", "My reply is no", "My sources say no",
                "Outlook not so good", "Very doubtful" };
        int choice = (int) (Math.random() * responses.length);
        return responses[choice];
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

        // This should be asking if the event represents clicking on the button
        // when the button's text is what it starts with
        if (e.getActionCommand().equals("Ask a question"))
            // This should be setting the text of the button using
            // randomResponce
            message.setText(randomResponse());
        // No if statement after the else needed here - if the button doesn't
        // have the text it started with, it must be displaying a random
        // response, which means we need to set the text back to what it started
        // with
        // We don't need this branch - delete it
        else
            message.setText("Ask a question");
    }
}