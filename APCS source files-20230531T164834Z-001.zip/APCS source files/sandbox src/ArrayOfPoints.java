import java.util.Arrays;

public class ArrayOfPoints
{

    public static void main(String[] args)
    {
        Point[] points = new Point[10];
        for (int i = 0; i < points.length; i++)
        {
            points[i] = new Point(i, i);
        }
        System.out.println(Arrays.toString(points));
        for (int i = 0; i < points.length; i++)
        {
            points[i].translate(1, 3);
        }
        System.out.println(Arrays.toString(points));
        for (int i = 0; i < points.length; i++)
        {
            if (points[i].getX() % 2 == 0)
            {
                points[i].invert();
            }
        }
        System.out.println(Arrays.toString(points));
    }

}
