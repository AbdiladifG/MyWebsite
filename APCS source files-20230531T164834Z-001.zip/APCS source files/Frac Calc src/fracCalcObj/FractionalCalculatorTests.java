package fracCalcObj;

import java.util.ArrayList;
import org.junit.Test;
import testHelp.*;

public class FractionalCalculatorTests
{
    @Test
    public void FracCalcShouldPrintGreetingFirst()
    {
        String response = ConsoleTester.getOutput("fracCalcObj.FracMain", "1_1/2 + 3/4\r\nquit");
        verify.that(response).matches("\\AWelcome to the Fraction Calculator!");
    }

    @Test
    public void FracCalcShouldPrintGoodbyeLast()
    {
        String response = ConsoleTester.getOutput("fracCalcObj.FracMain", "1_1/2 + 3/4\r\nquit");
        verify.that(response).matches("Goodbye!\\Z");
    }

    @Test
    public void FracCalcShouldQuitImmediatelyIfRequested()
    {
        String response = ConsoleTester.getOutput("fracCalcObj.FracMain", "quit");
        verify.that(response).matches(
                "Welcome to the Fraction Calculator!(\\s|\\n)+Enter an expression \\(or \"quit\"\\):(\\s|\\n)+Goodbye!");
    }

    @Test
    public void FracCalcShouldHandleMultipleInputsBeforeQuitting()
    {
        String response = ConsoleTester.getOutput("fracCalcObj.FracMain", "1/3 + 2/3\r\n4/5 + 5/6\r\nquit");
        ArrayList<String> answers = getAnswersFromOutput(response);
        verify.that(answers.size()).equals(2);
        verify.that(answers.get(0)).isFraction().isEquivalentTo("1");
        verify.that(answers.get(1)).isFraction().isEquivalentTo("49/30");
    }

    @Test
    public void FracCalcShouldAddFractionsCorrectlyv1()
    {
        String response = ConsoleTester.getOutput("fracCalcObj.FracMain", "2/3 + 1/6\r\nquit");
        ArrayList<String> answers = getAnswersFromOutput(response);
        verify.that(answers.get(0)).isFraction().isEquivalentTo("5/6");
    }

    @Test
    public void FracCalcShouldHandleZeroes()
    {
        String response = ConsoleTester.getOutput("fracCalcObj.FracMain", "0 * 4_2/3\r\nquit");
        ArrayList<String> answers = getAnswersFromOutput(response);
        verify.that(answers.get(0)).isFraction().isEquivalentTo("0");
    }

    @Test
    public void FracCalcShouldPrintReducedAnswer()
    {
        String response = ConsoleTester.getOutput("fracCalcObj.FracMain", "1_2/3 + 1/3\r\nquit");
        ArrayList<String> answers = getAnswersFromOutput(response);
        verify.that(answers.get(0)).equals("2");
    }

    @Test
    public void FracCalcShouldPrintReducedNegativeAnswer()
    {
        String response = ConsoleTester.getOutput("fracCalcObj.FracMain", "1_3/10 * -4\r\nquit");
        ArrayList<String> answers = getAnswersFromOutput(response);
        verify.that(answers.get(0)).equals("-5_1/5");
    }

    @Test
    public void NumericConstructorShouldSetNumAndDen()
    {
        Fraction test = new Fraction("21/28");
        verify.that(test.getNum()).equals(21);
        verify.that(test.getDen()).equals(28);
    }
    
    @Test
    public void StringConstructorShouldHandleWholeNumbers()
    {
        Fraction test = new Fraction("42");
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("42/1");
    }

    @Test
    public void StringConstructorShouldHandleMixedNumbers()
    {
        Fraction test = new Fraction("3_7/8");
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("31/8");
    }

    @Test
    public void StringConstructorShouldHandleProperFractions()
    {
        Fraction test = new Fraction("9/10");
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("9/10");
    }

    @Test
    public void StringConstructorShouldHandleImproperFractions()
    {
        Fraction test = new Fraction("7/3");
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("7/3");
    }

    @Test
    public void StringConstructorShouldHandleZero()
    {
        Fraction test = new Fraction("0");
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("0/1");
    }

    @Test
    public void StringConstructorShouldHandleNegativeWholeNumbers()
    {
        Fraction test = new Fraction("-19");
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("-19/1");
    }

    @Test
    public void StringConstructorShouldHandleNegativeMixedNumbers()
    {
        Fraction test = new Fraction("-1_2/3");
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("-5/3");
    }

    @Test
    public void StringConstructorShouldHandleNegativeFractions()
    {
        Fraction test = new Fraction("-5/6");
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("-5/6");
    }

    @Test
    public void FracCalcShouldAddFractionsCorrectly()
    {
        Fraction testa = new Fraction("3/5");
        Fraction testb = new Fraction("7/5");
        String output = fracCalcObj.FracMain.calculate(testa, "+", testb).toString();
        verify.that(output).isFraction().isEquivalentTo("2");
    }

    @Test
    public void FracCalcShouldSubstractFractionsCorrectly()
    {
        Fraction testa = new Fraction("3/5");
        Fraction testb = new Fraction("7/5");
        String output = fracCalcObj.FracMain.calculate(testa, "-", testb).toString();
        verify.that(output).isFraction().isEquivalentTo("-4/5");
    }

    @Test
    public void FracCalcShouldMultiplyFractionsCorrectly()
    {
        Fraction testa = new Fraction("3/5");
        Fraction testb = new Fraction("7/5");
        String output = fracCalcObj.FracMain.calculate(testa, "*", testb).toString();
        verify.that(output).isFraction().isEquivalentTo("21/25");
    }

    @Test
    public void FracCalcShouldDivideFractionsCorrectly()
    {
        Fraction testa = new Fraction("3/5");
        Fraction testb = new Fraction("7/5");
        String output = fracCalcObj.FracMain.calculate(testa, "/", testb).toString();
        verify.that(output).isFraction().isEquivalentTo("3/7");
    }

    @Test
    public void ReduceFunctionShouldReduceCorrectly()
    {
        Fraction test = new Fraction("14/6");
        test.reduce();
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("7/3");
    }

    @Test
    public void ReduceFunctionShouldReduceNegativeFractions()
    {
        Fraction test = new Fraction("-9/6");
        test.reduce();
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("-3/2");
    }

    @Test
    public void ReduceFunctionShouldHandleZero()
    {
        Fraction test = new Fraction("0/3");
        test.reduce();
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).matches("0/");
    }

    @Test
    public void ReduceFunctionShouldNotChangeFractionsAlreadyInLowestTerms()
    {
        Fraction test = new Fraction("3/17");
        test.reduce();
        String output = test.getNum() + "/" + test.getDen();
        verify.that(output).equals("3/17");
    }

    @Test
    public void toStringShouldNotChangeInstanceVariables()
    {
        Fraction test = new Fraction("12/18");
        String temp = test.toString();
        int n = test.getNum();
        int d = test.getDen();
        verify.that(n == 12).isTrue();
        verify.that(d == 18).isTrue();
    }
    
    @Test
    public void equalsMethodShouldNotChangeInstanceVariables()
    {
        Fraction testa = new Fraction("12/18");
        Fraction testb = new Fraction("10/5");
        boolean temp = testa.equals(testb);
        int na = testa.getNum();
        int da = testa.getDen();
        int nb = testb.getNum();
        int db = testb.getDen();
        verify.that(na == 12).isTrue();
        verify.that(da == 18).isTrue();
        verify.that(nb == 10).isTrue();
        verify.that(db == 5).isTrue();
    }
    
    @Test
    public void equalsMethodShouldBeTrueWhenFractionsAreIdentical()
    {
        Fraction testa = new Fraction("3/4");
        Fraction testb = new Fraction("3/4");
        verify.that(testa.equals(testb)).isTrue();
    }
    
    @Test
    public void equalsMethodShouldBeTrueWhenFractionsMadeWithBothConstructors()
    {
        Fraction testa = new Fraction("3/4");
        Fraction testb = new Fraction(3, 4);
        verify.that(testa.equals(testb)).isTrue();
    }
   
    @Test
    public void equalsMethodShouldBeTrueWhenFractionsNeedToBeReduced()
    {
        Fraction testa = new Fraction("3/4");
        Fraction testb = new Fraction("15/20");
        verify.that(testa.equals(testb)).isTrue();
    }
    
    @Test
    public void equalsMethodShouldBeFalseWhenFractionsAreDifferent()
    {
        Fraction testa = new Fraction("3/4");
        Fraction testb = new Fraction("4/3");
        verify.that(testa.equals(testb)).isFalse();
    }
    
    @Test
    public void equalsMethodShouldBeFalseWhenComparedToNonFraction()
    {
        Fraction testa = new Fraction("3/4");
        String testb = "testing 1 2 3";
        verify.that(testa.equals(testb)).isFalse();
    }
    
    @Test
    public void toStringFunctionShouldConvertWholeNumbers()
    {
        String output = new Fraction("6/1").toString();
        verify.that(output).equals("6");
    }

    @Test
    public void toStringFunctionShouldConvertNegativeNumbers()
    {
        String output = new Fraction("-12/7").toString();
        verify.that(output).equals("-1_5/7");
    }

    @Test
    public void toStringFunctionShouldLeaveProperFractionsAlone()
    {
        String output = new Fraction("4/19").toString();
        verify.that(output).equals("4/19");
    }

    @Test
    public void toStringShouldConvertImproperFractions()
    {
        String output = new Fraction("19/4").toString();
        verify.that(output).equals("4_3/4");
    }

    @Test
    public void toStringShouldHandleZero()
    {
        String output = new Fraction("0/1").toString();
        verify.that(output).equals("0");
    }

    private static ArrayList<String> getAnswersFromOutput(String output)
    {
        ArrayList<String> answers = new ArrayList<String>();
        String[] lines = output.split("\\n");
        for (int i = 1; i < lines.length - 1; i++)
            answers.add(lines[i].substring(lines[i].indexOf(": ") + 2).trim());
        return answers;
    }
}