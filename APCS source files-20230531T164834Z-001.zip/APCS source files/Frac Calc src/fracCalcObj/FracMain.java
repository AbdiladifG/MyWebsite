package fracCalcObj;

import java.util.Scanner;

/**********************************************************
 * Assignment: Frac Calc 4
 *
 * Author: Abdiladif Gurhan
 *
 * Description: Second part of the Fractional Calculator
 *
 * Academic Integrity: I pledge that this program represents my own work. I
 * received help from Bennett and my table members in designing and debugging my
 * program.
 **********************************************************/
public class FracMain
{

    public static Fraction calculate(Fraction left, String operator, Fraction right)
    {
        if (operator.equals("*"))
        {
            return left.times(right);
        }
        else if (operator.equals("+"))
        {
            return left.plus(right);
        }
        else if (operator.equals("/"))
        {
            return left.dividedBy(right);
        }
        else// subtraction
        {
            return left.minus(right);
        }
    }

    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.println("Welcome to the Fraction Calculator!");
        System.out.print("Enter an expression (or \"quit\"): ");
        String expression = console.nextLine();
        while (!expression.equals("quit"))
        {
            int space = expression.indexOf(" ");
            String left = expression.substring(0, space);
            Fraction leftFrac = new Fraction(left);

            String right = expression.substring(space + 3);
            Fraction rightFrac = new Fraction(right);

            String operator = expression.substring(space + 1, space + 2);

            Fraction result = calculate(leftFrac, operator, rightFrac);
            System.out.println(result);

            System.out.print("Enter an expression (or \"quit\"): ");
            expression = console.nextLine();

        }
        Fraction pi = new Fraction(22, 7);
        Fraction r = new Fraction(5, 1);
        Fraction semi = new Fraction(2, 1);
        System.out.println(pi.times(r).times(r).dividedBy(semi));
        System.out.print("Goodbye!");
    }
}
