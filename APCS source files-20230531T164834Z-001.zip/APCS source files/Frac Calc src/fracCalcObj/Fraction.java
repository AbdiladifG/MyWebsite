package fracCalcObj;

public class Fraction
{
    private int num;
    private int den;

    public Fraction(int n, int d)
    {
        num = n;
        den = d;
    }

    public Fraction(String s)
    {
        if (!s.contains("/"))
        {
            num = Integer.parseInt(s);
            den = 1;
        }
        else if (s.contains("_"))
        {
            int indexOfUnder = s.indexOf("_");
            int whole = getWhole(s, indexOfUnder);
            num = getNumerator(s.substring(indexOfUnder + 1));
            den = getDenominator(s.substring(indexOfUnder + 1));
            if (whole < 0)
                num = whole * den - num;
            else
                num = whole * den + num;
        }
        else
        {
            num = getNumerator(s);
            den = getDenominator(s);
        }
    }

    private int gcf()
    {
        int greatestSoFar = 1;
        for (int i = 2; i <= Math.abs(num); i++)
        {
            if (num % i == 0 && den % i == 0)
            {
                greatestSoFar = i;
            }
        }
        return greatestSoFar;
    }

    public void reduce()
    {
        int factor = gcf();
        num = num / factor;
        den = den / factor;
    }

    private int getNumerator(String fraction)
    {
        int slash = fraction.indexOf('/');
        String num = fraction.substring(0, slash);
        return Integer.parseInt(num);
    }

    private int getDenominator(String fraction)
    {
        int slash = fraction.indexOf('/');
        String den = fraction.substring(slash + 1);
        return Integer.parseInt(den);
    }

    private int getWhole(String input, int indexOfUnder)
    {
        String whole = input.substring(0, indexOfUnder);
        return Integer.parseInt(whole);
    }

    public int getNum()
    {
        return num;
    }

    public int getDen()
    {
        return den;
    }

    public Fraction plus(Fraction other)
    {
        int n = num * other.den + den * other.num;
        int d = den * other.den;
        return new Fraction(n, d);

    }

    public Fraction minus(Fraction other)
    {
        int n = num * other.den - den * other.num;
        int d = den * other.den;
        return new Fraction(n, d);
    }

    public Fraction times(Fraction other)
    {
        int n = num * other.num;
        int d = den * other.den;
        return new Fraction(n, d);
    }

    public Fraction dividedBy(Fraction other)
    {
        int n = num * other.den;
        int d = den * other.num;
        return new Fraction(n, d);
    }

    public boolean equals(Object other)
    {
        if (!(other instanceof Fraction))
        {
            return false;
        }
        Fraction oth = (Fraction) other;
        Fraction copy = new Fraction(num, den);
        Fraction frac = new Fraction(oth.getNum(), oth.getDen());
        copy.reduce();
        frac.reduce();

        return copy.num == frac.num && copy.den == frac.den;
    }

    public String toString()
    {
        Fraction copy = new Fraction(num, den);
        copy.reduce();
        if (copy.den == 1)
        {
            return copy.num + "";
        }
        else if (Math.abs(copy.num) > copy.den)
        {
            return copy.num / copy.den + "_" + Math.abs(copy.num % copy.den) + "/" + copy.den;
        }
        else
            return copy.num + "/" + copy.den;
    }
}