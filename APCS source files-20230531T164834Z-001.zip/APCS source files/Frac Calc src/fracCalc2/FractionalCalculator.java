package fracCalc2;

import java.util.Scanner;
/**********************************************************
 * Assignment: Frac Calc 2
 *
 * Author: Abdiladif Gurhan
 *
 * Description: Second part of the Fractional Calculator
 *
 * Academic Integrity: I pledge that this program represents my own work. I
 * received help from Bennett and my table members in designing and debugging
 * my program.
 **********************************************************/
public class FractionalCalculator
{
    public static String convertToFraction(String input)
    {
        // if input doesn't have / its a whole number
        // else if input contains an underscore its a mixed number
        // else its a regular fraction
        // input = indexOf('/') == -1
        if (!input.contains("/"))
        {
            return input + "/1";
        }
         
        else if (input.contains("_"))
        {
            
            int negative = input.indexOf('-');
            int slash = input.indexOf('/');
            int underscore = input.indexOf('_');
            
            int whole = Integer.parseInt(input.substring(0, underscore));
            
            int num = Integer.parseInt(input.substring(underscore + 1, slash));
            
            int den = Integer.parseInt(input.substring(slash + 1));
            
            if (input.contains("-"))
            {
                int wholen = Integer.parseInt(input.substring(negative + 1, underscore));
                int numn = Integer.parseInt(input.substring(underscore + 1, slash));
                int denn = Integer.parseInt(input.substring(slash + 1));
                int mixedn = (wholen * denn) + numn;
                String fracn = "-" + mixedn + "/" + denn;
                return fracn;
            }
            else
            {
                int mixed = ((whole * den) + num);
                String frac = mixed + "/" + den;
                return frac;
            }
        }
        
        else
        {
            return input;
        }
    }
    
    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.println("Welcome to the Fraction Calculator!");
        System.out.println("Enter an expression (or \"quit\"):");
        String expression = console.nextLine();
        while(!expression.equals("quit"))
        {
            
            int space = expression.indexOf(' ');
            String left = expression.substring(0, space);
            left = convertToFraction(left);
            String right = expression.substring(space + 3);
            right = convertToFraction(right);
            String operator = expression.substring(space + 1, space + 2);
            
            
            System.out.println("Left operand: " + left);
            System.out.println("Operator: " + operator);
            System.out.println("Right operand: " + right);
            System.out.println("Enter an expression (or \"quit\"):");
            expression = console.nextLine();
            
        }
        System.out.print("Goodbye!");
    }
}
