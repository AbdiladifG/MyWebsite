package fracCalc1;

import java.util.Scanner;

public class FractionalCalculator
{

    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.println("Welcome to the Fraction Calculator!");
        System.out.print("Enter an expression (or \"quit\"):");
        String expression = console.nextLine();
        
        // 3 lines of code to store each part of the expression
        int space = expression.indexOf(' ');
        String left = expression.substring(0, space);
        String right = expression.substring(space + 3);
        String operator = expression.substring(space + 1, space + 2);
        
        System.out.println("Left operand: " + left);
        System.out.println("Operator: " + operator);
        System.out.println("Right operand: " + right);
        System.out.print("Goodbye!");
    }

}
