package activity4;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.Test;

import testHelp.*;

public class ElevensBoardUnitTestsRef
{
    String[] suits0 = {};
    int[] values0 = {};
    String[] ranks0 = {};
    
    String[] suits2 = { "Diamonds", "Hearts"};
    int[] values2 = {5 };
    String[] ranks2 = {"5"};
    
    String[] suits11 = { "Diamonds", "Hearts"};
    int[] values11 = { 3, 4, 5, 6, 7 };
    String[] ranks11 = {"3", "4", "5", "6", "7"};
    
    String[] suitsJQK = { "Spades", "Clubs" };
    int[] valuesJQK = { 9, 10, 11, 12, 13 };
    String[] ranksJQK = {"9", "10", "Jack", "Queen", "King" };
    
    String[] suitsJQKonly = { "Clubs" };
    int[] valuesJQKonly = {11, 12, 13 };
    String[] ranksJQKonly = {"Jack", "Queen", "King" };
    
    String[] suits47only = { "Clubs" };
    int[] values47only = {4, 7};
    String[] ranks47only = {"4", "7" };
    
    String[] suitsQQQ = { "Diamonds", "Hearts", "Spades" };
    int[] valuesQQQ = { 1, 2, 12 };
    String[] ranksQQQ = { "Ace", "2", "Queen"};
    
    String[] suitsX = { "Diamonds", "Hearts", "Spades", "Clubs" };
    int[] valuesX = {2, 4, 6, 8, 10, 12, 13 };
    String[] ranksX = { "2", "4", "6", "8", "10", "Queen", "King" };
    
    String[] suitsWinningMix = { "Diamonds", "Spades"};
    int[] valuesWinningMix = {3, 8, 11, 12, 13 };
    String[] ranksWinningMix = { "3", "8", "Jack", "Queen", "King" };
    
    String[] suitsWinningAllRoyals = { "Diamonds", "Spades", "Hearts"};
    int[] valuesWinningAllRoyals = { 11, 12, 13 };
    String[] ranksWinningAllRoyals = { "Jack", "Queen", "King" };
    
    String[] suitsWinningNoRoyals = { "Diamonds", "Spades"};
    int[] valuesWinningNoRoyals = { 1, 10, 2, 9, 3, 8 };
    String[] ranksWinningNoRoyals = { "1", "10", "2", "9", "3", "8" };
    
    List<Integer> indicesEmpty = new ArrayList<Integer>();
    List<Integer> indices01 = Arrays.asList(new Integer[] { new Integer(0), new Integer(1) });
    List<Integer> indices27 = Arrays.asList(new Integer[] { new Integer(2), new Integer(7) });
    List<Integer> indices012 = Arrays.asList(new Integer[] { new Integer(0), new Integer(1), new Integer(2) });
    List<Integer> indices0123 = Arrays.asList(new Integer[] { new Integer(0), new Integer(1), new Integer(2), new Integer(3) });
    
    @Test
    public void BoardConstructorShouldNotThrow()
    {
        verify.that(() -> new ElevensBoard()).doesNotThrow();
    }

    @Test
    public void BoardShouldHoldNineCards()
    {
        IBoard board = new ElevensBoard();
        verify.that(board.getBoardSize()).isEqualTo(9);
    }

    @Test
    public void BoardShouldStartWithNineCards()
    {
        IBoard board = new ElevensBoard();
        verify.that(board.getCardIndices().size()).isEqualTo(9);
    }

    @Test
    public void NewGameShouldReplaceCards()
    {
        IBoard board = new ElevensBoard();
        ArrayList<Card> firstGame = getCards(board);
        board.newGame();
        ArrayList<Card> secondGame = getCards(board);
        verify.that(firstGame).isNotEqualTo(secondGame);
    }

    @Test
    public void DealShouldReplaceCardAtFirstIndex()
    {
        IBoard board = new ElevensBoard();
        Card test0 = board.getCard(0);
        board.deal(0);
        Card test1 = board.getCard(0);
        verify.that(test0).isNotEqualTo(test1);
        
    }

    @Test
    public void DealShouldReplaceCardAtLastIndex()
    {
        IBoard board = new ElevensBoard();
        Card test0 = board.getCard(8);
        board.deal(8);
        Card test1 = board.getCard(8);
        verify.that(test0).isNotEqualTo(test1);
    }

    @Test
    public void GameIsWonIfDeckAndTableAreClear()
    {
        Deck empty = new Deck(ranks0, suits0, values0);
        IBoard board = new ElevensBoard(empty);
        verify.that(board.gameIsWon()).isTrue();
    }

    @Test
    public void GameIsNotWonIfDeckContainsCards()
    {
        IBoard board = new ElevensBoard();
        verify.that(board.gameIsWon()).isFalse();
    }

    @Test
    public void GameIsNotWonIfTableHasCards()
    {
        Deck twoCards = new Deck(ranks2, suits2, values2);
        IBoard board = new ElevensBoard(twoCards); // will have 2 cards on table, none left in deck
        verify.that(board.gameIsWon()).isFalse();
    }

    @Test
    public void TableSlotsAreEmptyWhenDeckRunsOut()
    {
        Deck twoCards = new Deck(ranks2, suits2, values2);
        IBoard board = new ElevensBoard(twoCards);
        verify.that(board.getCardsLeftInDeck()).isEqualTo(0);

        // there should be just two card indices, 0 and 1
        verify.that(board.getCardIndices()).isEqualTo(indices01);
    }
    
    @Test
    public void ReplaceSelectedCardsShouldChangeCards()
    {
        IBoard board = new ElevensBoard();
        Card test2 = board.getCard(2);
        Card test7 = board.getCard(7);
        board.replaceSelectedCards(indices27);
        Card test2a = board.getCard(2);
        Card test7a = board.getCard(7);
        verify.that(test2).isNotEqualTo(test2a);
        verify.that(test7).isNotEqualTo(test7a);
    }
    
    @Test
    public void AnotherPlayIsPossibleShouldBeTrueFor11()
    {
        Deck deckThatHas11s = new Deck(ranks11, suits11, values11);
        IBoard board = new ElevensBoard(deckThatHas11s);
        verify.that(board.anotherPlayIsPossible()).isTrue();
    }
    
    @Test
    public void AnotherPlayIsPossibleShouldBeTrueForJQK()
    {
        Deck deckThatHasJQKs = new Deck(ranksJQK, suitsJQK, valuesJQK);
        IBoard board = new ElevensBoard(deckThatHasJQKs);
        verify.that(board.anotherPlayIsPossible()).isTrue();
    }
    
    @Test
    public void AnotherPlayIsPossibleShouldBeFalseForQQQ()
    {
        Deck QQQButNoJK = new Deck(ranksQQQ, suitsQQQ, valuesQQQ);
        IBoard board = new ElevensBoard(QQQButNoJK);
        verify.that(board.anotherPlayIsPossible()).isFalse();
    }

    @Test
    public void AnotherPlayIsPossibleShouldBeFalseForNoPlays()
    {
        Deck deckWithNoPlays = new Deck(ranksX, suitsX, valuesX);
        IBoard board = new ElevensBoard(deckWithNoPlays);
        verify.that(board.anotherPlayIsPossible()).isFalse();
    }
    
    @Test
    public void AnotherPlayIsPossibleShouldNotCrashAtEnd()
    {
        // onBoard will have some null values
        Deck winningDeckAtEnd = new Deck(ranksWinningMix, suitsWinningMix, valuesWinningMix); // 10 card deck
        IBoard board = new ElevensBoard(winningDeckAtEnd);
        board.deal(2); // to empty the deck
        board.deal(2); board.deal(7); // board should have nulls at 2 and 7
        verify.that(board.anotherPlayIsPossible()).isTrue();
        
        Deck winningDeckWithRoyals = new Deck(ranksWinningAllRoyals, suitsWinningAllRoyals, valuesWinningAllRoyals); // 9 card deck
        board = new ElevensBoard(winningDeckWithRoyals);
        board.deal(2); board.deal(7); // board should have nulls at 2 and 7
        verify.that(board.anotherPlayIsPossible()).isTrue();
        
        Deck winningDeckNoRoyals = new Deck(ranksWinningNoRoyals, suitsWinningNoRoyals, valuesWinningNoRoyals); // 10 card deck
        board = new ElevensBoard(winningDeckNoRoyals);
        board.deal(2); board.deal(2); board.deal(7); // board should have nulls at 2 and 7
        verify.that(board.anotherPlayIsPossible()).isTrue();
    }
    
    @Test
    public void IsLegalShouldBeFalseForNoSelectedCards()
    {
        IBoard board = new ElevensBoard();
        verify.that(board.isLegal(indicesEmpty)).isFalse();
    }
    
    @Test
    public void IsLegalShouldBeTrueForTwoCardsWhoseSumIs11()
    {
        Deck willHave3And8 = new Deck(ranksWinningMix, suitsWinningMix, valuesWinningMix);
        IBoard board = new ElevensBoard(willHave3And8);
        ArrayList<Integer> indices = new ArrayList<Integer>();
        indices.add(findCardOnBoard(board, 3));
        indices.add(findCardOnBoard(board, 8));
        verify.that(board.isLegal(indices)).isTrue();
    }
    
    @Test
    public void IsLegalShouldBeTrueForThreeCardsJQK()
    {
        Deck onlyJQK = new Deck(ranksJQKonly, suitsJQKonly, valuesJQKonly);
        IBoard board = new ElevensBoard(onlyJQK);
        verify.that(board.isLegal(indices012)).isTrue();
    }
    
    @Test
    public void IsLegalShouldBeFalseForTooManySelectedCards()
    {
        IBoard board = new ElevensBoard();
        verify.that(board.isLegal(indices0123)).isFalse();
    }
    
    private static ArrayList<Card> getCards(IBoard board)
    {
        ArrayList<Card> cards = new ArrayList<Card>();
        for (Integer i : board.getCardIndices())
            cards.add(board.getCard(i));
        return cards;
    }
    
    private int findCardOnBoard(IBoard board, int value)
    {
        ArrayList<Integer> indices = (ArrayList<Integer>) board.getCardIndices();
        for (int i : indices)
        {
            if (board.getCard(i).getValue() == value)
                return i;
        }
        return -1;
    }

}