package activity4;

import java.util.ArrayList;
import java.util.List;

public class ElevensBoard implements IBoard
{
    private Deck cards;
    private Card[] onBoard = new Card[9];

    public ElevensBoard()
    {
        String[] suits = { "Diamonds", "Hearts", "Spades", "Clubs" };
        int[] values = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };
        String[] ranks = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };
        cards = new Deck(ranks, suits, values);
        newGame();
    }

    public ElevensBoard(Deck d)
    {
        cards = d;
        newGame();
    }

    @Override
    public void newGame()
    {
        cards.shuffle();
        for (int i = 0; i < onBoard.length; i++)
        {
            deal(i);
        }

    }

    @Override
    public int getBoardSize()
    {
        return onBoard.length;
    }

    @Override
    public boolean isEmpty()
    {
        for (int i = 0; i < onBoard.length; i++)
        {
            if (onBoard[i] != null)
            {
                return false;
            }
        }
        return true;
    }

    @Override
    public void deal(int k)
    {
        onBoard[k] = cards.deal();
    }

    @Override
    public int getCardsLeftInDeck()
    {
        return cards.getCardsLeft();
    }

    @Override
    public Card getCard(int k)
    {
        return onBoard[k];
    }

    @Override
    public void replaceSelectedCards(List<Integer> selectedCards)
    {
        for (int i = 0; i < selectedCards.size(); i++)
        {
            deal(selectedCards.get(i));

        }

    }

    @Override
    public List<Integer> getCardIndices()
    {
        ArrayList<Integer> cardIndices = new ArrayList<Integer>();
        for (int i = 0; i < onBoard.length; i++)
        {
            if (!(onBoard[i] == null))
            {
                cardIndices.add(i);
            }
        }
        return cardIndices;
    }

    @Override
    public boolean gameIsWon()
    {
        if (cards.isEmpty() && isEmpty())
        {
            return true;
        }
        return false;
    }

    @Override
    public boolean isLegal(List<Integer> selectedCards)
    {
        if (selectedCards.size() < 2 || selectedCards.size() > 3)
        {
            return false;
        }
        else if (selectedCards.size() > 2)
        {
            String rankstring = onBoard[selectedCards.get(0)].getRank() + onBoard[selectedCards.get(1)].getRank()
                    + onBoard[selectedCards.get(2)].getRank();

            return rankstring.contains("K") && rankstring.contains("Q") && rankstring.contains("J");
        }
        int val1 = onBoard[selectedCards.get(0)].getValue();
        int val2 = onBoard[selectedCards.get(1)].getValue();
        // getCard(selectedCards.get(0));
        return val1 + val2 == 11;
    }

    @Override
    public boolean anotherPlayIsPossible()
    {

        return boardHas11() || boardHasJQK();
    }

    private boolean boardHasJQK()
    {
        String ranks = "";
        for (int i = 0; i < onBoard.length; i++)
        {
            if (onBoard[i] != null)
            {
                ranks += onBoard[i].getRank();
            }
        }
        return ranks.contains("K") && ranks.contains("Q") && ranks.contains("J");
    }

    private boolean boardHas11()
    {
        String ranks = "";
        for (int i = 0; i < onBoard.length; i++)
        {
            if (onBoard[i] != null)
            {
                ranks += onBoard[i].getRank();
            }
        }
        return (ranks.contains("10") && ranks.contains("A")) || (ranks.contains("9") && ranks.contains("2"))
                || (ranks.contains("8") && ranks.contains("3")) || (ranks.contains("7") && ranks.contains("4"))
                || (ranks.contains("6") && ranks.contains("5"));
    }

    // additional methods would be here

}