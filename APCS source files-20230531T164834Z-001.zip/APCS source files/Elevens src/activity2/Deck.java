package activity2;

import java.util.ArrayList;

/**
 * The Deck class represents a shuffled deck of cards. It provides several
 * operations including a constructor, shuffle, deal, and check if empty.
 */
public class Deck
{
    ArrayList<Card> cards;
    ArrayList<Card> used;
    /**
     * Creates a new Deck instance.
     * 
     * It pairs each element of ranks with each element of suits, and produces one
     * of the corresponding card.
     * 
     * @param ranks  is an array containing all of the card ranks.
     * @param suits  is an array containing all of the card suits.
     * @param values is an array containing all of the card point values.
     */
    public Deck(String[] ranks, String[] suits, int[] values)
    {
        cards = new ArrayList<Card>();
        for (int r = 0; r < ranks.length; r++)
        {
            for (int s = 0; s < suits.length; s++)
            {
                Card c = new Card(ranks[r], suits[s], values[r]);
                cards.add(c);
            }
        }
        used = new ArrayList<Card>();
    }

    /**
     * Determines if this deck is empty (no undealt cards).
     * 
     * @return true if this deck is empty, false otherwise.
     */
    public boolean isEmpty()
    {
        return cards.size() == 0;
    }

    /**
     * Accesses the number of undealt cards in this deck.
     * 
     * @return the number of undealt cards in this deck.
     */
    public int getCardsLeft()
    {
        return cards.size();
    }

    /**
     * Randomly permute the given collection of cards and reset the size to
     * represent the entire deck.
     */
    public void shuffle()
    {
        // add in all of the used cards first
        while (used.size() > 0)
        {
            cards.add(used.remove(0));
        }
        // mix them up
        for(int i = 0; i < 100; i++)
        {
            Card fred = cards.remove(0);
            int randPos = (int)(Math.random() * (cards.size() - 1));
            cards.add(randPos, fred);
        }
    }

    /**
     * Deals a card from this deck.
     * 
     * @return the card just dealt, or null if all the cards have been previously
     *         dealt.
     */
    public Card deal()
    {
        if(isEmpty())
        {
            return null;
        }
        Card fred = cards.remove(0);
        used.add(fred);
        return fred;
    }
}