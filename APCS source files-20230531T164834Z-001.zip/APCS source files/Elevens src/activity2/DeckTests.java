package activity2;

import java.util.ArrayList;

import org.junit.Test;

import testHelp.verify;

public class DeckTests
{
    String[] suits = { "hearts", "clubs", "diamonds", "spades" };
    String[] ranks = { "jack", "queen", "king" };
    int[] values = { 11, 12, 13 };
    String[] suits2 = { "hearts" };
    String[] ranks2 = { "jack" };
    int[] values2 = { 11 };
    String[] suits3 = {};
    String[] ranks3 = {};
    int[] values3 = {};

    @Test
    public void shouldBuildDeckOfSizeOne()
    {
        Deck d = new Deck(ranks2, suits2, values2);
        int size = d.getCardsLeft();
        verify.that(size).isEqualTo(1);
    }

    @Test
    public void shouldReturnCorrectSize()
    {
        Deck d = new Deck(ranks, suits, values);
        int size = d.getCardsLeft();
        verify.that(size).isEqualTo(12);
    }

    @Test
    public void isEmptyIsTrueWhenEmpty()
    {
        Deck d = new Deck(ranks3, suits3, values3);
        verify.that(d.isEmpty()).isTrue("Because deck is empty");
    }

    @Test
    public void isEmptyIsFalseWhenFull()
    {
        Deck d = new Deck(ranks, suits, values);
        verify.that(d.isEmpty()).isFalse("Because deck is filled");
    }

    @Test
    public void dealReducesDeckSize()
    {
        Deck d = new Deck(ranks, suits, values);
        int size = d.getCardsLeft();
        d.deal();
        verify.that(size).isEqualTo(d.getCardsLeft() + 1);
    }

    @Test
    public void dealShouldReturnNullIfDeckIsEmpty()
    {
        Deck d = new Deck(ranks3, suits3, values3);
        verify.that(d.deal()).equals(null);
    }

    @Test
    public void shuffleShouldRandomizeOrder()
    {
        Deck d = new Deck(ranks, suits, values);
        ArrayList<Card> preShuffle = allCardsInDeck(d);
        d.shuffle();
        ArrayList<Card> postShuffle = allCardsInDeck(d);
        verify.that(preShuffle).isEquivalentTo(postShuffle);
        verify.that(preShuffle).isNotEqualTo(postShuffle);
    }

    private ArrayList<Card> allCardsInDeck(Deck d)
    {
        ArrayList<Card> cards = new ArrayList<Card>();
        while (!d.isEmpty())
        {
            cards.add(d.deal());
        }
        return cards;
    }

    @Test
    public void afterAllCardsDealtSizeShouldBeZero()
    {
        Deck d = new Deck(ranks, suits, values);
        for (int i = 0; i < 12; i++)
        {
            d.deal();
        }
        verify.that(d.getCardsLeft()).isEqualTo(0);
    }

    @Test
    public void dealReturnsUniqueCards()
    {
        ArrayList<Card> c = new ArrayList<>();
        Deck d = new Deck(ranks, suits, values);
        for (int i = 0; i < d.getCardsLeft(); i++)
        {
            Card c1 = d.deal();
            verify.that(c.contains(c1)).isFalse("Because it is a new card");
            c.add(c1);
        }
    }

    @Test
    public void containsAllCardsSpecifiedByConstructor()
    {
        ArrayList<Card> cards1 = new ArrayList<Card>();
        for (int i = 0; i < suits.length; i++)
        {
            for (int j = 0; j < ranks.length && j < values.length; j++)
            {
                Card c = new Card(ranks[j], suits[i], values[j]);
                cards1.add(c);
            }
        }
        Deck d = new Deck(ranks, suits, values);
        ArrayList<Card> cards2 = allCardsInDeck(d);
        verify.that(cards1).isEquivalentTo(cards2);

    }

    @Test
    public void shuffleResetsGetCardsLeft()
    {
        Deck d = new Deck(ranks, suits, values);
        int remains = d.getCardsLeft();
        d.deal();
        d.shuffle();
        verify.that(remains).isEqualTo(d.getCardsLeft());
    }
}