package activity1;

import org.junit.Test;

import testHelp.*;

public class CardTests
{

    @Test
    public void CardConstructorShouldNotCrash()
    {
        Card test = new Card("Two", "Hearts", 2);
        verify.that(test).isOfType(Card.class);
    }
    
    @Test
    public void GetRankShouldReturnRank()
    {
        Card test = new Card("Two", "Hearts", 2);
        verify.that(test.getRank()).isEqualTo("Two");
    }
    
    @Test
    public void GetSuitShouldReturnSuit()
    {
        Card test = new Card("Two", "Hearts", 2);
        verify.that(test.getSuit()).isEqualTo("Hearts");
    }
    
    @Test
    public void GetValueShouldReturnPointValue()
    {
        Card test = new Card("Two", "Hearts", 2);
        verify.that(test.getValue()).isEqualTo(2);
    }
       
    @Test
    public void EqualsShouldReturnFalseForDifferentValue()
    {
        Card a = new Card("Ace", "Spades", 1);
        Card b = new Card("Ace", "Spades", 2);
        verify.that(a.equals(b)).isFalse("because value is different");
    }
   
    @Test
    public void EqualsShouldReturnFalseForDifferentRank()
    {
        Card a = new Card("Ace", "Spades", 1);
        Card b = new Card("Donut", "Spades", 1);
        verify.that(a.equals(b)).isFalse("because rank is different");
    }
   
    @Test
    public void EqualsShouldReturnFalseForDifferentSuit()
    {
        Card a = new Card("Ace", "Spades", 1);
        Card b = new Card("Ace", "Donuts", 1);
        verify.that(a.equals(b)).isFalse("because suit is different");
    }
    
    @Test
    public void EqualsShouldReturnTrueForSameRankSuitValue()
    {
        Card a = new Card("Ace", "Spades", 1);
        Card b = new Card("Ace", "Spades", 1);
        verify.that(a.equals(b)).isTrue();
    }
   
    @Test
    public void EqualsShouldReturnTrueForSelf()
    {
        Card a = new Card("Ace", "Spades", 1);
        verify.that(a.equals(a)).isTrue();
    }
   
    @Test
    public void EqualsShouldReturnFalseForNonCard()
    {
        Card a = new Card("Ace", "Spades", 1);
        verify.that(a.equals("Test")).isFalse("because a String is not a Card");
    }
  
    @Test
    public void toStringReturnsPropervalue()
    {
        Card a = new Card("Ace", "Spades", 1);
        verify.that(a.toString()).isEqualTo("Ace of Spades (point value = 1)");
    }

}