import java.util.Scanner;

public class TemperatureStats
{

    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.println("How many temperatures will you enter?");
        int temps = console.nextInt();
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        double avg = 0;
        int tempsum = 0;

        for (int i = 0; i < temps; i++)
        {
            System.out.print("Enter temp " + (i + 1) + ": ");
            int input = console.nextInt();
            if (input < min)
            {
                min = input;
            }
            if (input > max)
            {
                max = input;
            }
            tempsum = tempsum + input;
            avg = tempsum / temps;
        }

        System.out.println("The min temp is: " + min);
        System.out.println("The max temp is " + max);
        System.out.println("The avg is: " + avg);
    }

}
