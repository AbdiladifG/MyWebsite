import java.util.Scanner;

public class Person
{
    int age;
    String name = "";

    public void Person1()
    {
        Scanner console = new Scanner(System.in);
        System.out.println("Enter the person's name.");
        name = console.nextLine();
        System.out.println("Enter the person's age.");
        age = console.nextInt();
        System.out.println(name + " is " + age + " years old.");
    }

}
