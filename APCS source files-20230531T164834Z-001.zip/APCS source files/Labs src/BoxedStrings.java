import java.util.Scanner;

public class BoxedStrings
{

    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.print("Enter a string (or \"quit\"):");
        String bstring = console.nextLine();
        
        for (int i = 0; i < bstring.length() * 2 + 1; i++)
        {
            System.out.print("-");
        }
        
        System.out.println("");
        
        for (int i = 0; i < bstring.length(); i++)
        {
            System.out.print("|" + bstring.charAt(i));
        }
        
        System.out.println("|");

        for (int i = 0; i < bstring.length() * 2; i++)
        {
            System.out.print("-");
        }
    }

}
