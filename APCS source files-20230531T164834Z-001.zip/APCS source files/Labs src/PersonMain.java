import java.util.Scanner;

public class PersonMain
{

    public static void main(String[] args)
    {
        Person fred = new Person();
        fred.Person1();
        Scanner console = new Scanner(System.in);
        System.out.println("Enter the person's name.");
        fred.name = console.nextLine();
        System.out.println("Enter the person's age.");
        fred.age = console.nextInt();
        System.out.println(fred.name + " is " + fred.age + " years old.");
    }

}
