
public class ForLoops
{
    public static void triangle()

    {
        for (int i = 1; i < 5; i++)
        {
            for (int j = 0; j < i; j++)
            {
                System.out.print("*");
            }
            System.out.println(" ");
        }

    }

    public static void main(String[] args)
    {
        System.out.print("1 ");
        System.out.print("1 ");
        int previous = 1;
        int previous2 = 1;

        for (int i = 0; i < 10; i++)
        {
            int value = previous + previous2;
            System.out.print(value);
            previous = previous2;
            previous2 = value;
            System.out.print(" ");
        }

        System.out.println("");
        System.out.println("");
        triangle();

    }

}
