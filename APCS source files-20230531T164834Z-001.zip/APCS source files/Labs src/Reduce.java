import java.util.Scanner;

public class Reduce
{
    public static int gcf(int num1, int num2)
    {
        int greatestSoFar = 1;
        for (int f = 2; f <= num1; f++)
        {
            if (num1 % f == 0 && num2 % f == 0) // replace false to fix
            {
                greatestSoFar = f; // replace 0 to fix
            }
        }
        return greatestSoFar;
    }

    
    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.println("Enter a numerator: ");
        int num = console.nextInt();
        System.out.println("Enter a denominator: ");
        int den = console.nextInt();
        System.out.println(num + "/" + den + " reduced to lowest terms is: ");

        // print out the original fraction
        int factor = gcf(num, den);
        num = num / factor;
        den = den / factor;
        System.out.println(num + "/" + den);
        // print out the reduced fraction
    }
}
