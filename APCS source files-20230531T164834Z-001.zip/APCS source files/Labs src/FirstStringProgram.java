
public class FirstStringProgram
{

    public static void main(String[] args)
    {
        String myName = "Abdiladif Gurhan";

        System.out.println(myName.substring(0, 9));

        System.out.println(myName.substring(10));

        for (int i = 0; i < 16; i++)
        {
            System.out.println(myName.charAt(i));
        }

    }

}
