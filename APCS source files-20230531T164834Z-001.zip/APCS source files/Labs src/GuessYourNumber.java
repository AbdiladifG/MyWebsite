import java.util.Scanner;

// A program that asks the user to think of a number, then tries
// to guess what it was.
public class GuessYourNumber {

    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        int[] numbersToGuess = initializeNumbers(10);
        
        System.out.println("Think of a number between 1 and 10 and I'll try to guess it.");
        
        // Choose a number to guess, then ask the user if it was the right one. The
        // key thing here is that we're randomly choosing the INDEX of the number to 
        // guess, not directly choosing a number.
        int indexOfGuess = /* missing code */
        System.out.print("Was it " + numbersToGuess[indexOfGuess] + "? ");
        /* missing code */
        
        // Until the user says 'yes', keep guessing.
        while (/* missing code */)
        {
            // Remove the number we just guessed from the list of numbers, so
            // we don't guess it again. If we run out of numbers, the user is
            // cheating!
            numbersToGuess = /* missing code */
            if (/* missing code */)
            {
                System.out.println("What?!? That was all the numbers!");
                return;
            }
            
            // Pick another number to guess, and ask the user if it is correct.
            indexOfGuess = /* missing code */;
            System.out.print("Okay, then was it " + numbersToGuess[indexOfGuess] + "? ");
            answer = input.nextLine();
        }
        
        // The user said we got it.
        System.out.println("Woohoo!");
    }
    
    // Set up an array with 'howMany' counting numbers numbers in it, starting at 1.
    public static int[] initializeNumbers(int howMany)
    {
        /* missing code */
        howMany = 1;
        for (int i = 0; i < howMany; i++)
        {
            
        }
        
        return numbers;
    }
    
    // Remove the number at 'index' from the array 'list' by constructing a new array
    // that doesn't include the number we want to skip, and return that new array.
    public static int[] removeNumberFromList(int[] list, int index)
    {
        // make a new array that is one element smaller than the old one
        int[] newList = /* missing code */
        
        // copy all the values up to but not including the one we want to
        // leave out
        for (int i = 0; i < index; i++)
        {
            newList[i] = /* missing code */
        }
        
        // copy all the values *after* the one we want to leave out
        for (int j = index; j < newList.length; j++)
        {
            newList[j] = /* missing code */
        }
        
        /* missing code */
    }
}