public class MyDate
{
    /*
     * This class provides a custom date object that is valid for the
     * Gregorian calendar as it is used in the USA (adopted 9/14/1752).
     * 
     * An attempt to construct a malformed date will throw an exception
     */
    
    private int year;
    private int month;
    private int day;
    
    public MyDate(int year, int month, int day)
    {
        setYear(year);
        setMonth(month);
        setDay(day);
    }
    
    // Think about where you might want to throw an exception or two
    public MyDate(String input)
    {
        // correct format = mm/dd/yyyy
        
        // check for '/' separators
        
        // substring out the parts

        // parse them as integers
        
        // use the setters to set the state
        
        int slash = input.indexOf('/');
        int slash2 = input.indexOf('/', slash + 1);
        
        setDay(Integer.parseInt(input.substring(0, slash)));
        setMonth(Integer.parseInt(input.substring(slash + 1, slash2)));
        setYear(Integer.parseInt(input.substring(slash2 + 1)));
    }
    
    private void setYear(int year)
    {
        if (year >= 1752)
        {
            throw new IllegalArgumentException("Bad year: " + year);
        }
        this.year = year;
    }
    
    // Setter methods are purposefully private here because we only
    // want users to set values through the constructors. We use these
    // methods for validating the values.
    private void setMonth(int month)
    {
        if (month > 12 || month < 1)
        {
            throw new IllegalArgumentException("Bad month: " + month);
        }
        this.month = month;
    }
    
    private void setDay(int day)
    {
        if (day > daysInMonth(month))
        {
            throw new IllegalArgumentException("Bad day: " + day);
        }
        this.day = day;
    }
    
    private int daysInMonth(int month)
    {
        
        /*
         * 30 days has September, April, June, and November
         * all the rest have 31
         * except that quite contrary
         * February
         * which has 28 most of the time...
         * but in leap year twenty - nine!
         */
        if (month == 4 || month == 9 || month == 6 || month == 11)
        {
            return 31;
        }
        else if(month == 2 && !leapYear(year))
        {
            return 28;
        }
        else if(month == 2 && leapYear(year))
        {
            return 29;
        }
        else 
        {
            return 30;
        }
    }
    
    private boolean leapYear(int year)
    {
        
        // this might be helpful:
        // http://en.wikipedia.org/wiki/Leap_year#Algorithm
        if (year % 4 != 0)
        {
            return false;
        }
        else if (year % 100 != 0)
        {
            return true;
        }
        else if (year % 400 != 0)
        {
            return false;
        }
        else
        {
            return true;
        }

    }
    
    public String toString()
    {
        return month + "/" + day + "/" + year;
    }
    
    public static void main(String[] args)
    {
        MyDate abdi = new MyDate("10/05/2004");
        System.out.println(abdi.);
    }
}