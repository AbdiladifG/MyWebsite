import java.util.Scanner;

public class Reducev2
{
    public static int gcf(int num1, int num2)
    {
        int greatestSoFar = 1;
        for (int f = 2; f <= num1; f++)
        {
            if (num1 % f == 0 && num2 % f == 0) // replace false to fix
            {
                greatestSoFar = f; // replace 0 to fix
            }
        }
        return greatestSoFar;
    }

    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);
        System.out.print("Enter an expression: ");
        String expression = console.nextLine();

        int slash = expression.indexOf('/');
        String left = expression.substring(0, slash);
        String right = expression.substring(slash + 1);

        int num = Integer.parseInt(left);
        int den = Integer.parseInt(right);

        int factor = gcf(num, den);
        num = num / factor;
        den = den / factor;
        System.out.println(expression + " reduced to lowest terms is: " + num + "/" + den);
    }
}
