import java.util.Scanner;

public class MonteCarlo
{
    private static boolean inCircle(double x, double y)
    {
        return (Math.sqrt(x * x + y * y) <= 1);
    }

    
    public static void main(String[] args)
    {
        int hits;
        Scanner console = new Scanner(System.in);
        System.out.println("Happy Pi Day!");
        System.out.println("How many darts would you like to throw?");
        int howMany = console.nextInt();
        while (howMany != 0)
        {
            hits = 0;
            for (int i = 0; i < howMany; i++)
            {
                double x = Math.random() * 2 - 1;
                double y = Math.random() * 2 - 1;
                if (inCircle(x, y))
                {
                    hits += 1;
                }
            }
            double piApprox = ((hits * 1.0) / howMany) * 4;
            System.out.println("Hits = " + hits);
            System.out.println("Total = " + howMany);
            System.out.println("Pi Approximate = " + piApprox);
            System.out.println("How many darts would you like to throw?");
            howMany = console.nextInt();
        }
        System.out.println("Done!");
    }
}