
public class CurvingGrades
{

    public static void main(String[] args)
    {
        
    }

}
