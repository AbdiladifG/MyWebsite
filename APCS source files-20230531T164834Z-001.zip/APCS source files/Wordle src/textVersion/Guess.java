package textVersion;

/**
 * This class is used by GameState to represent a guess in the game, including
 * the LetterStatus of each letter in the guess
 * 
 * @author DMcGlathery
 *
 */
public class Guess
{
    private GuessedLetter[] theGuess;

    /**
     * Constructor for Guess. Assumes all letters are incorrect to start and has the
     * GameState score the letters otherwise.
     */
    public Guess(String g, GameState p)
    {
        theGuess = new GuessedLetter[5];
        char[] chars = g.toCharArray();
        for (int i = 0; i < 5; i++)
        {
            theGuess[i] = new GuessedLetter(chars[i], LetterStatus.NOTINWORD);
        }
        p.scoreGuess(this);
    }

    /**
     * Returns the i-th GuessedLetter in the Guess
     */
    public GuessedLetter getLetter(int i)
    {
        return theGuess[i];
    }

    /**
     * Returns the number of letters in correct position in the Guess
     */
    public int lettersCorrect()
    {
        int count = 0;
        for (GuessedLetter letter : theGuess)
        {
            if(letter.getStatus() == LetterStatus.CORRECT)
            {
                count++;
            }
        }
        return count;
    }

    /**
     * Returns a String representation of Guess
     */
    public String toString()
    {
        String result = "";
        for (GuessedLetter ch : theGuess)
        {
            if (ch.getStatus() == LetterStatus.NOTINWORD)
                result += "-";
            else if (ch.getStatus() == LetterStatus.WRONGPOSITION)
                result += (ch.getLetter() + "").toLowerCase();
            else
                result += (ch.getLetter() + "").toUpperCase();
        }
        return result;
    }
}
