package textVersion;

/**
 * This class is used by Guess to represent a single letter and its status
 * 
 * @author DMcGlathery
 *
 */
public class GuessedLetter
{
    private char theLetter;
    private LetterStatus status;

    public GuessedLetter(char letter, LetterStatus s)
    {
        theLetter = letter;
        status = s;
    }

    /**
     * Returns the LetterStatus of this letter
     */
    public LetterStatus getStatus()
    {
        return status;
    }

    /**
     * Returns the char of this letter
     */
    public char getLetter()
    {
        return theLetter;
    }

    /**
     * Sets the status of this letter
     */
    public void setStatus(LetterStatus s)
    {
        status = s;
    }
}
