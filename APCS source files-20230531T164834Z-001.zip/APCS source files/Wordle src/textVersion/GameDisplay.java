package textVersion;
/**
 * This class hosts the game loop and displays the state of the game.
 * @author DMcGlathery
 *
 */
public class GameDisplay
{
    public final static String INDENT = "      ";
    private Interactions user;
    private GameState state;
    private boolean debugging = false;

    public GameDisplay(GameState g)
    {
        state = g;
        user = new Interactions(state);
    }

    /**
     * The main game loop
     * Displays the state of the game
     */
    public void playGame()
    {
        System.out.println("Welcome to APCS Wordle (the text version)!");
        System.out.println("   [Capital letters: correct position]");
        System.out.println("   [Lowercase letters: wrong position]\n");
        if (debugging)
            System.out.println("Debugging] Secret word is: " + state.showSecret());
        
        while (!state.getSolved() && state.anyGuessesLeft())
        {
            if (state.getNumberOfGuesses() != 0)
                showAlphabet();
            String guess = user.getUserGuess();
            state.processGuess(guess);
            displayPuzzle();
        }
        if (state.getSolved())
        {
            System.out.println("Yay");
        }
        else
        {
            System.out.println("Boo. The word was " + state.showSecret() + ".");
        }
    }

    /**
     * Shows the status of all letters in the alphabetic with respect to the current
     * game
     */
    private void showAlphabet()
    {
        Alphabet alpha = state.getAlphabet();
        System.out.print(INDENT + "Yes: " + alpha.markedPresent());
        System.out.print("No: " + alpha.markedAbsent());
        System.out.println("  Unused: " + alpha.unusedLetters());
    }

    private void displayPuzzle()
    {
        System.out.println(state.getCurrentGuess());
    }

}
