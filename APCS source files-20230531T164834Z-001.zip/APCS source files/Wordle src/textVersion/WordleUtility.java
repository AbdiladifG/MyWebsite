package textVersion;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class provides a tool for reading text files
 * 
 * @author DMcGlathery
 *
 */
public class WordleUtility
{
    public static ArrayList<String> getWords(String filename)
    {
        FileReader inputFile = null;
        try
        {
            inputFile = new FileReader(filename);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        Scanner fileScanner = new Scanner(inputFile);
        ArrayList<String> wordList = new ArrayList<String>();
        String word;

        while (fileScanner.hasNextLine())
        {
//            word = fileScanner.nextLine().toUpperCase();
            word = fileScanner.nextLine();
            wordList.add(word);
        }

        fileScanner.close();
        return wordList;
    }
}
