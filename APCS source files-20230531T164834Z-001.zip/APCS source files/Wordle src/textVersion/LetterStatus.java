package textVersion;

/**
 * This is a custom type that represents the different possible status of a
 * letter that has been part of a guess.
 * 
 * @author DMcGlathery
 *
 */
public enum LetterStatus
{
    NOTINWORD, WRONGPOSITION, CORRECT
}
