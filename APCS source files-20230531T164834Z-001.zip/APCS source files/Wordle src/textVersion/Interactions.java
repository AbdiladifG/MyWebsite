package textVersion;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class handles interactions with the player. Its primary job is to get
 * and validate the user's guesses.
 * 
 * @Dependency: expects the presence of a text file "validWords" in the
 *              workspace folder of the project containing all words considered
 *              to be valid guesses.
 * 
 * @author DMcGlathery
 *
 */
public class Interactions
{
    private Scanner console;
    private GameState state;
    private ArrayList<String> validWords;

    public Interactions(GameState g)
    {
        state = g;
        validWords = WordleUtility.getWords("validWords.txt");
        console = new Scanner(System.in);
    }

    /**
     * Handles interaction with user
     * 
     * @return a valid guess (user input that exist in the list of valid words)
     */
    public String getUserGuess()
    {
        int numGuesses = state.getNumberOfGuesses();
        String[] ord = { "1st", "2nd", "3rd", "4th", "5th", "last" };
        System.out.print(GameDisplay.INDENT + "Enter your " + ord[numGuesses] + " guess: ");
        String guess = console.nextLine().toUpperCase();
        while(!isValid(guess))
        {
            System.out.println(GameDisplay.INDENT + "Not in word list");
            System.out.print(GameDisplay.INDENT + "Re-enter your guess: ");
            guess = console.nextLine().toUpperCase();
        }
        return guess;
    }

    /**
     * Helper method. Returns whether is the guess is valid based on the validWords
     * list
     */
    private boolean isValid(String guess)
    {
        return guess.length() == 5 && validWords.contains(guess);
    }
}
