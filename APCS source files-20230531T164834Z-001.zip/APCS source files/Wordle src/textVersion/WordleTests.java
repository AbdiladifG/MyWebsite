package textVersion;

import java.util.ArrayList;
import org.junit.Test;
import testHelp.*;

public class WordleTests
{
    @Test
    public void AlphabetShouldHaveNullValuesForUnusedLetters()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("HELLO");
        verify.that(test.getAlphabet().getStatus('B')).equals(null);
    }

    @Test
    public void AlphabetShouldHaveCorrectStatusForCorrectLetters()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("HELLO");
        Alphabet alpha = test.getAlphabet();
        LetterStatus status = alpha.getStatus('E');
        verify.that(status.equals(LetterStatus.CORRECT)).isTrue();
    }

    @Test
    public void AlphabetShouldHaveCorrectStatusForWrongPosLetters()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("SCRAP");
        Alphabet alpha = test.getAlphabet();
        LetterStatus status = alpha.getStatus('S');
        verify.that(status.equals(LetterStatus.WRONGPOSITION)).isTrue();
    }

    @Test
    public void AlphabetShouldHaveCorrectStatusForIncorrectLetters()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("SCRAP");
        Alphabet alpha = test.getAlphabet();
        LetterStatus status = alpha.getStatus('R');
        verify.that(status.equals(LetterStatus.NOTINWORD)).isTrue();
    }

    @Test
    public void AlphabetMarkedPresentShouldReturnCorrectString()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("TRIAL");
        test.processGuess("CRANE");
        Alphabet alpha = test.getAlphabet();
        String present = alpha.markedPresent();
        verify.that(present.equals("eT")).isTrue();
    }

    @Test
    public void AlphabetMarkedAbsentShouldReturnCorrectString()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("TRIAL");
        test.processGuess("CRANE");
        Alphabet alpha = test.getAlphabet();
        String absent = alpha.markedAbsent();
        verify.that(absent.equals("ACILNR")).isTrue();
    }

    @Test
    public void AlphabetUnusedLettersShouldReturnCorrectString()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("ABACK");
        test.processGuess("ZESTY");
        Alphabet alpha = test.getAlphabet();
        String unused = alpha.unusedLetters();
        verify.that(unused.equals("DFGHIJLMNOPQRUVWX")).isTrue();
    }

    @Test
    public void GuessLettersCorrectShouldReturn0()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("ABACK");
        Guess theGuess = test.getCurrentGuess();
        int correctLetters = theGuess.lettersCorrect();
        verify.that(correctLetters == 0).isTrue();
    }

    @Test
    public void GuessLettersCorrectShouldReturnCorrectNumber()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("TENTS");
        Guess theGuess = test.getCurrentGuess();
        int correctLetters = theGuess.lettersCorrect();
        verify.that(correctLetters == 4).isTrue();
    }

    @Test
    public void GuessToStringShouldWorkWhenWordIsAllCrrect()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("TESTS");
        Guess theGuess = test.getCurrentGuess();
        verify.that(theGuess.toString().equals("TESTS")).isTrue();
    }

    @Test
    public void GuessToStringShouldWorkWhenWordIsPartiallyCorrect()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("TREES");
        Guess theGuess = test.getCurrentGuess();
        verify.that(theGuess.toString().equals("T-e-S")).isTrue();
    }

    @Test
    public void GuessToStringShouldWorkWhenWordIsAllWrong()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("RADIO");
        Guess theGuess = test.getCurrentGuess();
        verify.that(theGuess.toString().equals("-----")).isTrue();
    }

    @Test
    public void GameStateGetSolvedShouldReturnFalseAtStart()
    {
        GameState test = new GameState();
        verify.that(test.getSolved()).isFalse();
    }

    @Test
    public void GameStateGetSolvedShouldReturnFalseAfterGuess()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("TREES");
        verify.that(test.getSolved()).isFalse();
    }

    @Test
    public void GameStateGetSolvedShouldReturnTrue()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("TENTS");
        test.processGuess("TESTS");
        verify.that(test.getSolved()).isTrue();
    }

    @Test
    public void GameStateGetNumberOfGuessesShouldReturnCorrect()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("RADIO");
        test.processGuess("TENTS");
        verify.that(test.getNumberOfGuesses() == 2).isTrue();
    }

    @Test
    public void GameStateAnyGuessesLeftShouldReturnTrue()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("RADIO");
        test.processGuess("TENTS");
        verify.that(test.anyGuessesLeft()).isTrue();
    }

    @Test
    public void GameStateAnyGuessesLeftShouldReturnFalse()
    {
        GameState test = new GameState("TESTS");
        test.processGuess("RADIO");
        test.processGuess("TENTS");
        test.processGuess("HELLO");
        test.processGuess("PROOF");
        test.processGuess("FORGO");
        test.processGuess("DELVE");
        verify.that(test.anyGuessesLeft()).isFalse();
    }

    @Test
    public void WordleWinningMsgShouldBeCorrectForOne()
    {
        GameState test = new GameState("LUCKY");
        test.processGuess("LUCKY");
        verify.that(test.getWinMessage()).equals("Genius");
    }
    
    @Test
    public void WordleWinningMsgShouldBeCorrectForTwo()
    {
        GameState test = new GameState("RADIO");
        test.processGuess("LUCKY");
        test.processGuess("RADIO");
        verify.that(test.getWinMessage()).equals("Magnificent");
    }
    
    @Test
    public void WordleWinningMsgShouldBeCorrectForThree()
    {
        GameState test = new GameState("TENTS");
        test.processGuess("LUCKY");
        test.processGuess("RADIO");
        test.processGuess("TENTS");
        verify.that(test.getWinMessage()).equals("Impressive");
    }
    
    @Test
    public void WordleWinningMsgShouldBeCorrectForFour()
    {
        GameState test = new GameState("HELLO");
        test.processGuess("LUCKY");
        test.processGuess("RADIO");
        test.processGuess("TENTS");
        test.processGuess("HELLO");
        verify.that(test.getWinMessage()).equals("Splendid");
    }
    
    @Test
    public void WordleWinningMsgShouldBeCorrectForFive()
    {
        GameState test = new GameState("PROOF");
        test.processGuess("LUCKY");
        test.processGuess("RADIO");
        test.processGuess("TENTS");
        test.processGuess("HELLO");
        test.processGuess("PROOF");
        verify.that(test.getWinMessage()).equals("Great");
    }
    
    @Test
    public void WordleWinningMsgShouldBeCorrectForSix()
    {
        GameState test = new GameState("FORGO");
        test.processGuess("LUCKY");
        test.processGuess("RADIO");
        test.processGuess("TENTS");
        test.processGuess("HELLO");
        test.processGuess("PROOF");
        test.processGuess("FORGO");
        verify.that(test.getWinMessage()).equals("Phew");
    }
}