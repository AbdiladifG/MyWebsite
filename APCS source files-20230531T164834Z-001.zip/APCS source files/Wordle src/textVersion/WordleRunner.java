package textVersion;

/**
 * Run this class to play the Wordle game
 * 
 * @author DMcGlathery
 *
 */
public class WordleRunner
{
    public static void main(String[] args)
    {
        GameState p = new GameState();
        GameDisplay disp = new GameDisplay(p);
        disp.playGame();
    }
}
