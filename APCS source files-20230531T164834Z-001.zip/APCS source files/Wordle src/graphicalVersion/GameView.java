package graphicalVersion;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GameView extends JFrame implements IChangeListener
{
    private GameState model;

    private LetterLabel[][] grid;
    private KeyButton[][] keys;

    public GameView(GameState g)
    {
        // set the value for the instance variable model
        model = g;
        // initialize the instance variable grid
        grid = new LetterLabel[6][5];
     // Create a new ActionHandler object
        ActionHandler handler = new ActionHandler(model);
        for(int r = 0; r < 6; r++)
        {
            for(int c = 0; c < 5; c++)
            {
                grid[r][c] = new LetterLabel("" , SwingConstants.CENTER);
            }
        }
        // finish initializing the instance variable keys
        keys = new KeyButton[3][];
        keys[0] = new KeyButton[10];
        keys[1] = new KeyButton[9];
        keys[2] = new KeyButton[7];
        String[][] letterKeys = { { "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P" },
                { "A", "S", "D", "F", "G", "H", "J", "K", "L" }, { "Z", "X", "C", "V", "B", "N", "M" } };
        
        for(int i = 0; i < 3; i++)
        {
            for(int j = 0; j < keys[i].length; j++)
            {
                keys[i][j] = new KeyButton(letterKeys[i][j]);
                keys[i][j].addActionListener(handler);
            }
        }
        
        // this next line registers the GameView with the GameState
        model.addListener(this);

        // set the title and size
        setTitle("Wordle");
        setSize(512, 620);
        // set the layout to a BorderLayout
        setLayout(new BorderLayout());
        // Build a center panel to hold all the grid and add it to the CENTER of the border layout
        JPanel center = buildCenterPanel();
        add(center, BorderLayout.CENTER);

        // Build spacer panels for the WEST and EAST
        JPanel west = buildSpacerPanel(20);
        add(west, BorderLayout.WEST);
        JPanel east = buildSpacerPanel(20);
        add(east, BorderLayout.EAST);
        
        // build a keyboard panel and add it to the SOUTH of the BoardLayout
        JPanel keyboard = buildKeyboardPanel(handler);
        add(keyboard, BorderLayout.SOUTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private JPanel buildSpacerPanel(int n)
    {
        JPanel spacer = new JPanel();
        spacer.setBackground(Color.white);
        String padding = "";
        for (int i = 0; i < n; i++)
            padding += " ";
        JLabel pad = new JLabel(padding);
        spacer.add(pad);
        return spacer;
    }

    public void display()
    {
        setVisible(true);
    }

    
    @Override
    public void redraw()
    {
        // set guess labels
        for(int r = 0; r < 6; r++)
        {
            for(int c = 0; c < 5; c++)
            {
                if(model.getGuess(r, c) != null)
                    {
                        grid[r][c].showLetter(model.getGuess(r, c));
                    }
                    
            }
        }
        // set keyboard buttons
        for(int r = 0; r < keys.length; r++)
        {
            for(int c = 0; c < keys[r].length; c++)
            {
                keys[r][c].showKey(model.getAlphabet());
            }
        }
        
        int row = model.getNumberOfGuesses();
        String partial = model.getEntry();
        if(row < 6 && !model.getSolved())
        {
            for(int c = 0; c < partial.length(); c++)
            {
                String letter = partial.charAt(c) + "";
                grid[row][c].showPartial(letter);
            }
            for(int c = partial.length(); c < 5; c++)
            {
                grid[row][c].showEmpty();
            }
        }
    }
    
    private JPanel buildKeyboardPanel(ActionHandler fred)
    {
        // create a JPanel and use the instance variable status to add a label
        // to the bottom panel

        JPanel keyboard = new JPanel(new GridLayout(3, 1));
        keyboard.setBackground(Color.white);
        JPanel row0 = new JPanel(new GridLayout(1, keys[0].length));

        JPanel row1 = new JPanel(new BorderLayout());
        row1.add(buildSpacerPanel(3), BorderLayout.WEST);
        row1.add(buildSpacerPanel(3), BorderLayout.EAST);
        JPanel row1Keys = new JPanel(new GridLayout(1, keys[1].length));
        row1Keys.setBackground(Color.white);
        row1.add(row1Keys, BorderLayout.CENTER);

        JPanel row2 = new JPanel(new BorderLayout());
        JPanel row2Keys = new JPanel(new GridLayout(1, keys[2].length));
        row2Keys.setBackground(Color.white);
        SpecialButton enter = new SpecialButton("Enter", 78, 65);
        row2.add(enter, BorderLayout.WEST);
        enter.addActionListener(fred);
        
        SpecialButton delete = new SpecialButton("Del", 70, 65);
        row2.add(delete, BorderLayout.EAST);
        delete.addActionListener(fred);
        row2.add(row2Keys, BorderLayout.CENTER);

        for (int c = 0; c < keys[0].length; c++)
            row0.add(keys[0][c]);
        for (int c = 0; c < keys[1].length; c++)
            row1Keys.add(keys[1][c]);
        for (int c = 0; c < keys[2].length; c++)
            row2Keys.add(keys[2][c]);
        keyboard.add(row0);
        keyboard.add(row1);
        keyboard.add(row2);
        return keyboard;
    }

    private JPanel buildCenterPanel()
    {
        // create a JPanel with a GridLayout
        // use the instance variable grid to fill the layout with labels
        JPanel center = new JPanel();
        GridLayout g = new GridLayout(6, 5);
        center.setLayout(g);
        for(int i = 0; i < 6; i++)
        {
            for(int j = 0; j < 5; j++)
            {
                center.add(grid[i][j]);
            }
        }
        return center;
    }

}