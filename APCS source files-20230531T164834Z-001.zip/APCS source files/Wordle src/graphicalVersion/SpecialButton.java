package graphicalVersion;

import java.awt.Dimension;

public class SpecialButton extends KeyButton
{

    public SpecialButton(String key, int w, int h)
    {
        super(key);
        setButtonSize(w, h);
    }
    
    private void setButtonSize(int width, int height)
    {
        setPreferredSize(new Dimension(width, height));
    }

}
