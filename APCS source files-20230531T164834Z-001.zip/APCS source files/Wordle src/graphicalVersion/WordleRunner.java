package graphicalVersion;

/**
 * Run this class to play the Wordle game
 * 
 * @author DMcGlathery
 *
 */
public class WordleRunner
{
    public static void main(String[] args)
    {
        GameState p = new GameState();
        GameView disp = new GameView(p);
        p.newGame();
        disp.display();
    }
}
