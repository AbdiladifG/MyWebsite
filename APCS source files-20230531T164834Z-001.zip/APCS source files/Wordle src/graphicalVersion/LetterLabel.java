package graphicalVersion;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.border.Border;

public class LetterLabel extends JLabel
{
    public LetterLabel(String string, int center)
    {
        super(string, center);
        setOpaque(true);
        setBackground(Color.white);
        setVerticalTextPosition(JLabel.CENTER);
        Border inner = BorderFactory.createLineBorder(WordleColors.UNUSED, 2);
        Border outer = BorderFactory.createLineBorder(Color.white, 2);
        setBorder(BorderFactory.createCompoundBorder(outer, inner));
        setFont(new Font("Arial", Font.BOLD, 40));
    }
    public void showPartial(String c)
    {
        Border inner = BorderFactory.createLineBorder(WordleColors.ENTRYBORDER, 2);
        Border outer = BorderFactory.createLineBorder(Color.white, 2);
        setBorder(BorderFactory.createCompoundBorder(outer, inner));
        setForeground(Color.black);
        setBackground(Color.white);
        setText(c);
    }
    public void showEmpty()
    {
        Border inner = BorderFactory.createLineBorder(WordleColors.UNUSED, 2);
        Border outer = BorderFactory.createLineBorder(Color.white, 2);
        setBorder(BorderFactory.createCompoundBorder(outer, inner));
        setBackground(Color.white);
        setText("");
    }
    public void showLetter(GuessedLetter guess)
    {
        Color tileColor;
        if (guess.getStatus() == LetterStatus.CORRECT)
            tileColor = WordleColors.CORRECT;
        else if(guess.getStatus() == LetterStatus.WRONGPOSITION)
            tileColor = WordleColors.PRESENT;
        else
            tileColor = WordleColors.ABSENT;
        
        Border inner = BorderFactory.createLineBorder(tileColor, 2);
        Border outer = BorderFactory.createLineBorder(Color.white, 2);
        setBorder(BorderFactory.createCompoundBorder(outer, inner));
        setForeground(Color.white);
        setBackground(tileColor);
        setText(guess.getLetter() + "");
    }
}
