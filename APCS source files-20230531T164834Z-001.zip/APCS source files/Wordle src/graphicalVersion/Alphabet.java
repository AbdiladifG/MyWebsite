package graphicalVersion;

/**
 * This class represents all possible letters that can be used in the game,
 * along with their current status based upon the guesses made so far. It is
 * analogous to the keyboard representation in the official graphical version of
 * the game. The status of all letters is initialized to null.
 * 
 * @author DMcGlathery
 *
 */
public class Alphabet
{
    private GuessedLetter[] alpha;

    public Alphabet()
    {
        alpha = new GuessedLetter[26];
        char letter = 'A';
        for (int i = 0; i < 26; i++)
        {
            alpha[i] = new GuessedLetter(letter, null);
            letter++;
        }
    }

    /**
     * Sets the status of letter in the alphabet
     */
    public void setLetter(char letter, LetterStatus status)
    {
        int index = letter - 'A';
        alpha[index].setStatus(status);
    }

    /**
     * Gets the LetterStatus of letter
     */
    public LetterStatus getStatus(char letter)
    {
        int index = letter - 'A';
        return alpha[index].getStatus();
    }
    
    /**
     * Returns all the letters marked as found in the word so far as a String.
     */
    public String markedPresent()
    {
        String result = "";
        for (char c = 'A'; c <= 'Z'; c++)
        {
            if (getStatus(c) == LetterStatus.CORRECT)
                result += (c + "").toUpperCase();
            if (getStatus(c) == LetterStatus.WRONGPOSITION)
                result += (c + "").toLowerCase();
        }
        return result;
    }
    
    /**
     * Returns all the letters marked as being absent from the word as a String.
     */
    public String markedAbsent()
    {
        String result = "";
        for (char c = 'A'; c <= 'Z'; c++)
        {
            if (getStatus(c) == LetterStatus.NOTINWORD)
                result += c;
        }  
        return result;
    }
    
    /**
     * Returns all the letters that have not been present in any guesses so far.
     */
    public String unusedLetters()
    {
        String result = "";
        for(char c = 'A'; c <= 'Z'; c++)
        {
            if (getStatus(c) == null)
                result += c;
        }
        return result;
    }

}
