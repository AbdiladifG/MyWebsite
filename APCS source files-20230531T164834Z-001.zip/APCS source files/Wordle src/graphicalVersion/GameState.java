package graphicalVersion;

import java.util.ArrayList;

/**
 * This class holds and maintains the state of the game.
 * 
 * @Dependency: Assumes the presence of a text file "wordleWords.txt" in the
 *              workspace folder of the project that contains all candidate
 *              secret words for the game.
 * 
 * @author DMcGlathery
 *
 */
public class GameState
{
    private String secret;
    private int numberOfGuesses;
    private Guess[] guesses;
    private Alphabet alpha;
    private ArrayList<IChangeListener> listeners;
    private String entry;

    public GameState()
    {
        secret = chooseRandomWord();
        numberOfGuesses = 0;
        guesses = new Guess[6];
        alpha = new Alphabet();
        listeners = new ArrayList<IChangeListener>();
        entry = "";
    }

    /**
     * For unit tests
     */
    public GameState(String word)
    {
        secret = word;
        numberOfGuesses = 0;
        guesses = new Guess[6];
        alpha = new Alphabet();
        listeners = new ArrayList<IChangeListener>();
        entry = "";
    }

    public String getEntry()
    {
        return entry;
    }
 // Append c to the end of entry as long as entry�s length is less than 5
    public void addToEntry(String c)
    {
        if(entry.length() < 5)
        {
            entry += c;
        }
        updateListeners();
    }
 // Remove the rightmost char from entry
    public void deleteFromEntry()
    {
        if(entry.length() != 0)
        {
            entry = entry.substring(0, entry.length() - 1);
        }
        updateListeners();
    }

    /**
     * Picks a random word from the candidate Wordle word list
     */
    private String chooseRandomWord()
    {
        ArrayList<String> words = WordleUtility.getWords("wordleWords.txt");
        int randIndex = (int) (Math.random() * words.size());
        return words.get(randIndex);
    }

    public GuessedLetter getGuess(int r, int c)
    {
        if(guesses[r] == null)
            return null;
        return guesses[r].getLetter(c);
    }
    public void addListener(IChangeListener fred)
    {
        listeners.add(fred);
    }

    public void updateListeners()
    {
        for (IChangeListener wilma : listeners)
            wilma.redraw();
    }

    public void newGame()
    {
        updateListeners();
    }

    /**
     * Returns the current guess in the puzzle
     * 
     * @Precondition: numberOfGuesses > 0
     */
    public Guess getCurrentGuess()
    {
        return guesses[numberOfGuesses - 1];
    }

    /**
     * Returns true if the puzzle has been solved
     */
    

    public boolean getSolved()
    {
        if (numberOfGuesses == 0)
            return false;
        Guess g = getCurrentGuess();
        return g.lettersCorrect() == 5;
    }

    /**
     * Returns true of there are any guesses left
     */
    public boolean anyGuessesLeft()
    {
        return numberOfGuesses < 6;
    }

    /**
     * Adds a validated guess to the puzzle. The Guess constructor calls
     * processGuess to score it.
     */
    public void processGuess(String guess)
    {
        guesses[numberOfGuesses] = new Guess(guess, this);
        numberOfGuesses++;
        updateAlpha();
        entry = "";
        updateListeners();
    }

    /**
     * Returns the number of guesses so far
     */
    public int getNumberOfGuesses()
    {
        return numberOfGuesses;
    }

    /**
     * Score the guess Modifies the LetterStatus of each letter in the guess. Called
     * from the Guess constructor which initializes the LetterStatus of all letters
     * in the guess to NOTINWORD.
     * 
     * @param guess - the validated guess to be scored.
     */
    public void scoreGuess(Guess guess)
    {
        char[] secretCopy = secret.toCharArray();

        secretCopy = scoreCorrectLetters(guess, secretCopy);
        scoreWrongPositionLetters(guess, secretCopy);
    }

    /**
     * Changes LetterStatus in appropriate letters in guess to CORRECT.
     * 
     * @param guess      the guess to be scored by comparing it to secret
     * @param secretCopy a copy of the secret word
     * @return secretCopy with matched letters converted to spaces
     */
    private char[] scoreCorrectLetters(Guess guess, char[] secretCopy)
    {
        for (int i = 0; i < 5; i++)
        {
            char guessLet = guess.getLetter(i).getLetter();
            if (secretCopy[i] == guessLet)
            {
                guess.getLetter(i).setStatus(LetterStatus.CORRECT);
                secretCopy[i] = ' ';
            }
        }
        return secretCopy;
    }

    /**
     * Changes LetterStatus in appropriate letters in guess to WRONGPOSITION.
     * 
     * @param guess      the guess to be scored
     * @param secretCopy a copy of the secret word with correct matched letters
     *                   removed
     */
    private void scoreWrongPositionLetters(Guess guess, char[] secretCopy)
    {
        // for every letter in guess that has not been changed
        // check it against every letter in secret. if it matches, change its status to
        // WRONGPOSITION and change the letter in secret to a space.
        for (int i = 0; i < 5; i++) // iterate through the letters in guess
        {
            char guessLet = guess.getLetter(i).getLetter();

            int j = 0; // iterate through the letters in secret
            while (guess.getLetter(i).getStatus() == LetterStatus.NOTINWORD && j < 5)
            {
                if (secretCopy[j] == guessLet)
                {
                    guess.getLetter(i).setStatus(LetterStatus.WRONGPOSITION);
                    secretCopy[j] = ' ';
                }
                j++;
            }
        }
    }

    public String showSecret()
    {
        return secret;
    }

    /**
     * Uses the currentGuess to update the LetterStatus for letters in the alphabet.
     * If the letter has previously been marked as CORRECT its status is not
     * changed.
     * 
     * @Precondition: currentGuess has been processed
     */
    public void updateAlpha()
    {
        Guess current = getCurrentGuess();
        for (int i = 0; i < 5; i++)
        {
            GuessedLetter let = current.getLetter(i);
            LetterStatus currentStatus = alpha.getStatus(let.getLetter());
            LetterStatus guessStatus = let.getStatus();
            if (currentStatus == null || guessStatus.ordinal() > currentStatus.ordinal())
            {
                alpha.setLetter(let.getLetter(), let.getStatus());
            }
        }
    }

    public Alphabet getAlphabet()
    {
        return alpha;
    }

    public String getWinMessage()
    {
        if (getSolved())
        {
            if (getNumberOfGuesses() == 1)
            {
                return "Genius";
            }
            else if (getNumberOfGuesses() == 2)
            {
                return "Magnificent";
            }
            else if (getNumberOfGuesses() == 3)
            {
                return "Impressive";
            }
            else if (getNumberOfGuesses() == 4)
            {
                return "Splendid";
            }
            else if (getNumberOfGuesses() == 5)
            {
                return "Great";
            }
            else if (getNumberOfGuesses() == 6)
            {
                return "Phew";
            }
        }
        return null;

    }

}
