package graphicalVersion;

import java.awt.Color;
/**
 * This class is used by the View module to color elements in the GUI
 * 
 * @author DMcGlathery
 *
 */
public class WordleColors
{
    public static final Color CORRECT = new Color(106, 170, 100);
    public static final Color PRESENT = new Color(201, 180, 88);
    public static final Color ABSENT = new Color(120, 124, 126);
    public static final Color UNUSED = new Color(211, 214, 218); // for the keyboard
    public static final Color ENTRYBORDER = new Color(135, 138, 140); // while a guess is being entered
}
