package graphicalVersion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ActionHandler implements ActionListener
{
    private GameState g;
    private ArrayList<String> validWords;

    public ActionHandler(GameState model)
    {
        g = model;
        validWords = WordleUtility.getWords("validWords.txt");
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String keyname = e.getActionCommand();
        if (letters.contains(keyname))
            g.addToEntry(keyname);
        else if (keyname.equals("Del"))
            g.deleteFromEntry();
        else if (isValid(g.getEntry()))
            g.processGuess(g.getEntry());
        else
            ;
            
        
    }
    
    /**
     * Helper method. Returns whether is the guess is valid based on the validWords
     * list
     */
    private boolean isValid(String guess)
    {
        return guess.length() == 5 && validWords.contains(guess);
    }

}
