package graphicalVersion;
public interface IChangeListener 
{
	public void redraw();
}
