package graphicalVersion;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;

public class KeyButton extends JButton
{
    public KeyButton(String key)
    {
        super(key);
        setOpaque(true);
        setBackground(WordleColors.UNUSED);
        setButtonSize(20, 65);
        setFont(new Font("Arial", Font.BOLD, 14));
        setBorder(BorderFactory.createLineBorder(Color.white, 4));
    }
    
    private void setButtonSize(int width, int height)
    {
        setPreferredSize(new Dimension(width, height));
    }
    
    public void showKey(Alphabet alpha)
    {
        Color keyColor;
        char c = this.getText().charAt(0);
        LetterStatus status = alpha.getStatus(c);
        if(status != null)
        {
            if(status == LetterStatus.CORRECT)
                keyColor = WordleColors.CORRECT;
            else if(status == LetterStatus.WRONGPOSITION)
                keyColor = WordleColors.PRESENT;
            else
                keyColor = WordleColors.ABSENT;
            setForeground(Color.white);
            setBackground(keyColor);
        }
    }

}
