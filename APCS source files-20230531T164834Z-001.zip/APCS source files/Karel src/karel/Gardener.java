package karel;

import kareltherobot.*;

public class Gardener extends UrRobot
{
    public Gardener(int street, int avenue, Direction direction, int beepers)
    {
        
        super(street, avenue, direction, beepers);
        
    }
    public void turnRight()
    {
        turnLeft();
        turnLeft();
        turnLeft();
    }
    public void move3()
    {
        putBeeper();
        move();
        putBeeper();
        move();
        putBeeper();
        move();
    }
    public void nextCorner()
    {
        putBeeper();
        turnRight();
        move();
        turnRight();
    }
    public void plantCorner()

    {
        move3();
        turnLeft();
        move3();
    }
    public static void main(String[] args)
    {
        World.readWorld("WorldFiles/fig3-8.kwld");
        World.setVisible(true);
        
        Gardener karel = new Gardener(2, 2, South, 28);
        World.setDelay(4);
        
        karel.turnLeft();
        karel.move();
        karel.move();
        karel.move();
        karel.turnLeft();
        karel.plantCorner();
        karel.nextCorner();
        karel.plantCorner();
        karel.nextCorner();
        karel.plantCorner();
        karel.nextCorner();
        karel.plantCorner();
        karel.nextCorner();
        karel.turnLeft();
        karel.move();
        karel.move();
        karel.move();
        karel.turnLeft();
        karel.turnOff();
        
    }

}