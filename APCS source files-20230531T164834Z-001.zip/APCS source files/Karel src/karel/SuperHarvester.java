package karel;

import kareltherobot.*;

public class SuperHarvester extends CleverRobot
{
    public SuperHarvester(int street, int avenue, Direction dir, int beeps)
    {
        super(street, avenue, dir, beeps);
    }

    //
    // Add methods here to support the plan in your main method to solve the problem
    //
    public void turnRight()
    {
        turnLeft();
        turnLeft();
        turnLeft();
    }

    // pre: The robot picked up the last beeper in a line
    // post: it lands on the first beeper on the next lin
    public void leftCorner()
    {
        turnLeft();
        move();
        turnLeft();
        move();
    }

    // pre: The robot picked up the last beeper in a line
    // post: it lands on the first beeper on the next line
    public void rightCorner()
    {
        turnRight();
        move();
        turnRight();
        move();
    }

    // pre: robot starts at the first beeper in a line
    // post: The robot stops after picking the last beeper in a pile
    public void beeperLoop()
    {
        while (nextToABeeper())
        {
            pickBeeperPile();
            move();
        }
    }

    public static void main(String[] args)
    {
        SuperField.loadRandomWorld();
        World.setVisible(true);

        SuperHarvester betty = new SuperHarvester(2, 2, East, 0);
        World.setDelay(4);

        //
        // Add calls to methods that represent your plan for solving the problem
        //
        betty.move();
        while (betty.nextToABeeper())
        {
            betty.beeperLoop();
            betty.leftCorner();
            betty.beeperLoop();
            betty.rightCorner();
        }

        betty.faceWest();
        betty.goToWall();
        betty.faceSouth();
        betty.goToWall();
        betty.faceNorth();

        betty.turnOff();

    }

}