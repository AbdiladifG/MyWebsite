package karel;

import kareltherobot.*;

public class Climber extends UrRobot
{
    public Climber(int street, int avenue, Direction dir, int beeps)
    {
        super(street, avenue, dir, beeps);
    }
    
    public void turnRight()
    {
        turnLeft();
        turnLeft();
        turnLeft();
    }
    public static void main(String[] args)
    {
        // World file (leave out the readWorld line if you just want a blank world)
        World.readWorld("WorldFiles/fig2-9.kwld");
        World.setVisible(true);

        Climber karel = new Climber(1, 2, East, 1);
        // Your instructions to complete this task should go below this line
        karel.move();
        karel.turnLeft();
        karel.move();
        karel.move();
        karel.turnRight();
        karel.move();
        karel.turnLeft();
        karel.move();
        karel.move();
        karel.turnRight();
        karel.move();
        karel.putBeeper();
        karel.move();
        karel.turnRight();
        karel.move();
        karel.move();
        karel.turnLeft();
        karel.move();
        karel.turnRight();
        karel.move();
        karel.move();
        karel.turnLeft();
        karel.turnOff();
    }

}