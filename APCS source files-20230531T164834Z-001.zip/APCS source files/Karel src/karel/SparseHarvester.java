package karel;

import kareltherobot.*;

public class SparseHarvester extends Robot
{
    public SparseHarvester(int street, int avenue, Direction dir, int beeps)
    {
        super(street, avenue, dir, beeps);
    }

    //
    // Add methods here to support the plan in your main method to solve the problem
    //
    public void turnRight()
    {
        turnLeft();
        turnLeft();
        turnLeft();
    }

    public void move4()
    {
        checkBeeper();
        checkBeeper();
        checkBeeper();
        checkBeeper();
    }

    public void leftCorner()
    {
        turnLeft();
        checkBeeper();
        turnLeft();
    }

    public void rightCorner()
    {
        turnRight();
        checkBeeper();
        turnRight();
    }

    public void checkBeeper()
    {
        if (!nextToABeeper())
        {
            move();
        }
        else
        {
            pickBeeper();
            move();
        }
    }

    public static void main(String[] args)
    {
        SparseWorld.loadRandomWorld();
        World.setVisible(true);

        SparseHarvester betty = new SparseHarvester(2, 2, East, 0);
        World.setDelay(4);

        //
        // Add calls to methods that represent your plan for solving the problem
        //
        betty.checkBeeper();
        betty.move4();
        betty.leftCorner();
        betty.move4();
        betty.rightCorner();
        betty.move4();
        betty.leftCorner();
        betty.move4();
        betty.rightCorner();
        betty.move4();
        betty.leftCorner();
        betty.move4();
        betty.pickBeeper();
        betty.turnOff();

    }

}