package karel;

import kareltherobot.*;

public class Hurdles extends CleverRobot
{
    public Hurdles(int street, int avenue, Direction dir, int beeps)
    {
        super(street, avenue, dir, beeps);
    }

    //
    // Add methods here to support the plan in your main method to solve the problem

    // pre: The front has to be blocked
    // post: It gets the robot in position to climb another step or to the top of a
    // wall
    public void wallStep()
    {
        while (!frontIsClear())
        {
            turnLeft();
            move();
            turnRight();
        }
    }

    // pre: There can't be any beepers in the bag
    // post: The robot picked up the beeper
    public void findBeeper()
    {
        while (!anyBeepersInBeeperBag())
        {
            if (frontIsClear())
            {
                move();
            }
            else
            {
                jumpHurdle();
            }
            if (nextToABeeper())
            {
                pickBeeper();
            }
        }
    }

    // pre: The robot has to be facing a wall
    // post: The robot is left on the ground after climbing a hurdle facing east
    public void jumpHurdle()
    {
        wallStep();
        move();
        faceSouth();
        wallStep();
        goToWall();
        turnLeft();
    }

    public static void main(String[] args)
    {
        MakeHurdles.loadRandomWorld();
        World.setVisible(true);

        Hurdles betty = new Hurdles(1, 1, East, 0);
        World.setDelay(5);

        //
        // Add calls to methods that represent your plan for solving the problem
        //
        betty.findBeeper();
        betty.turnOff();
    }

}