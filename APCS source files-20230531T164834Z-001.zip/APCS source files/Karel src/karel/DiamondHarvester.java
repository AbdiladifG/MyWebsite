package karel;

import kareltherobot.*;

public class DiamondHarvester extends UrRobot
{
    public DiamondHarvester(int street, int avenue, Direction dir, int beeps)
    {
        super(street, avenue, dir, beeps);
    }

    //
    // Add methods here to support the plan in your main method to solve the problem
    //
    public void turnRight()
    {
        turnLeft();
        turnLeft();
        turnLeft();
    }

    public void move1()
    {
        pickBeeper();
        move();
        turnLeft();
        move();
        turnRight();
    }

    public void move2()
    {
        pickBeeper();
        move();
        turnRight();
        move();
        turnLeft();
    }

    public void leftCorner()
    {
        pickBeeper();
        turnLeft();
        move();
        turnLeft();
        move();
    }

    public void rightCorner()
    {
        pickBeeper();
        move();
        turnRight();
        move();
    }

    public static void main(String[] args)
    {
        World.readWorld("WorldFiles/fig3-5.kwld");
        World.setVisible(true);

        DiamondHarvester betty = new DiamondHarvester(2, 2, East, 0);
        World.setDelay(20);

        //
        // Add calls to methods that represent your plan for solving the problem
        //
        betty.move();
        betty.move();
        betty.move();
        betty.move();
        betty.move1();
        betty.move1();
        betty.move1();
        betty.leftCorner();
        betty.move1();
        betty.move1();
        betty.move1();
        betty.rightCorner();
        betty.move2();
        betty.move2();
        betty.move2();
        betty.pickBeeper();
        betty.move();
        betty.turnLeft();
        betty.move();
        betty.move1();
        betty.move1();
        betty.move1();
        betty.pickBeeper();
        betty.turnOff();

    }

}