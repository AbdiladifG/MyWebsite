package karel;

import kareltherobot.*;

public class MicroMazeRunner extends Robot
{
    public MicroMazeRunner(int street, int avenue, Direction dir, int beeps)
    {
        super(street, avenue, dir, beeps);
    }

    //
    // Add methods here to support the plan in your main method to solve the problem
    //

    public static void main(String [] args)
    {
    	MicroMaze.loadMicroMaze();
        World.setVisible(true);

        MicroMazeRunner barney = MicroMaze.placeKarel();
        World.setDelay(20);

        //
        // Add calls to methods that represent your plan for solving the problem
        //

        barney.turnOff();
    }

}