package cp2;

import java.util.ArrayList;

public interface TextAnalyzer
{
    /*
     * Checkpoint 1 methods
     */

    /**
     * Return how many times a word occurs
     * 
     */
    int getWordCounts(String word);

    /**
     * Return true if the word starts with a capital letter; false otherwise
     * 
     */
    boolean startsWithCapitalLetter(String word);

    /**
     * Return true if the word is ".", "?", or "!"
     * 
     */
    boolean isSentenceEndingPunctuation(String word);

    /*
     * Checkpoint 2 methods For Checkpoint 1, your code will have to include these
     * methods, but they will not be tested until Checkpoint 2 You can just return
     * null for now, or throw new UnsupportedOperationException();
     */

    /**
     * Given a word from the text, return a list of all the words that could come
     * next. Includes duplicates.
     * 
     */
    ArrayList<String> getWordsThatCouldComeNext(String prevWord);

    /**
     * Return a list of all the words in the text that start with a capital letter.
     * Includes duplicates.
     * 
     */
    ArrayList<String> getAllWordsThatStartWithACapitalLetter();

    /**
     * Return the number of sentences in the text. Assume that each time the word
     * ".", "?", or "!" occurs, that's one sentence
     * 
     */
    int numberOfSentences();
}