package cp3;

import java.util.ArrayList;
import java.util.Random;

public class SentenceGenerator
{
    TextAnalyzer counter;
    Random random;

    public SentenceGenerator(String filename)
    {
        counter = new WordCounter(filename);
        this.random = new Random();
    }

    public SentenceGenerator(String filename, Random random)
    {
        counter = new WordCounter(filename);
        this.random = random;
    }

    // given any word from the source text, randomly choose a word that
    // could come next, using the TextAnalyzer wordsThatCouldComeNext method
    // and the randomlySelectWord method below
    // return that word as a String
    public String randomlyChooseNextWord(String prevWord)
    {
        String r = randomlySelectWord(counter.getWordsThatCouldComeNext(prevWord));
        return r;

        // TODO: implement this method
    }

    // given a starting word, generate a random word that could come next, and a
    // random word that could come after that, etc.
    // keep going until you generate punctuation that could end a sentence, as
    // determined by TextAnalyzer isSentenceEndingPunctuation
    public String generateRandomSentence(String firstWord)
    {
        String sentence = firstWord;
        String nextWord = randomlyChooseNextWord(firstWord);
        while (!counter.isSentenceEndingPunctuation(nextWord))
        {
            if (!nextWord.equals(","))
            {
                sentence += " ";
                sentence += nextWord;
            }
            else
            {
                sentence += nextWord;
            }
            nextWord = randomlyChooseNextWord(nextWord);
        }
        return sentence + nextWord;

    }

    // randomly choose a word that starts with a capital letter, and use that as
    // the first word of the sentence
    // then randomly generate the rest of the sentence using
    // generateRandomSentence(String firstWord)
    public String generateRandomSentence()
    {
        String r = randomlySelectWord(counter.getAllWordsThatStartWithACapitalLetter());
        String result = generateRandomSentence(r);
        return result;
    }

    private String randomlySelectWord(ArrayList<String> possibleWords)
    {
        int randomIndex = random.nextInt(possibleWords.size());
        return possibleWords.get(randomIndex);
    }

    public static void main(String[] args)
    {
        SentenceGenerator sg = new SentenceGenerator("alice_tokenized.txt");

        System.out.println(sg.generateRandomSentence("Alice"));
        System.out.println(sg.generateRandomSentence("She"));
        System.out.println(sg.generateRandomSentence());
        System.out.println(sg.generateRandomSentence());
        System.out.println(sg.generateRandomSentence());
        System.out.println(sg.generateRandomSentence("There"));
        System.out.println(sg.generateRandomSentence("This"));
        System.out.println("The End");
    }
}