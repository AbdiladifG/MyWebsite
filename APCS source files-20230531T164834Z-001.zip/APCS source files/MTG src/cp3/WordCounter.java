package cp3;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**********************************************************
 * Assignment: MTG
 *
 * Author: Abdiladif Gurhan
 *
 * Description: Second part of the Fractional Calculator
 *
 * Academic Integrity: I pledge that this program represents my own work. I
 * received help from my table members in designing and debugging my program.
 **********************************************************/
public class WordCounter implements TextAnalyzer
{

    private HashMap<String, Integer> words;
    private ArrayList<String> capitals;
    private HashMap<String, ArrayList<String>> nextWords;

    public WordCounter(String filename)
    {
        FileReader file = null;
        words = new HashMap<String, Integer>();
        capitals = new ArrayList<String>();
        nextWords = new HashMap<String, ArrayList<String>>();
        try
        {
            file = new FileReader(filename);
        }
        catch (FileNotFoundException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        Scanner fileScanner = new Scanner(file);
        String previous = "";
        while (fileScanner.hasNext())
        {
            // read next token use .next,
            // check to see if the token is already in the hashmap
            // if it is, increment count for token
            // else, add it to the hashmap with a count of 1
            // check to see if token is in nextwords hashmap

            String token = fileScanner.next();
            if (startsWithCapitalLetter(token))
            {
                capitals.add(token);
            }

            if (words.containsKey(token))
            {
                int count = words.get(token);
                count++;
                words.put(token, count);
            }

            else
            {
                words.put(token, 1);
            }

            if (nextWords.containsKey(previous))
            {
                ArrayList<String> fred = nextWords.get(previous);
                fred.add(token);
                nextWords.put(previous, fred);
            }
            else
            {
                ArrayList<String> wilma = new ArrayList<String>();
                wilma.add(token);
                nextWords.put(previous, wilma);
            }
            
            previous = token;

        }

    }

    @Override
    public int getWordCounts(String word)
    {
        return words.get(word);
    }

    @Override
    public boolean startsWithCapitalLetter(String word)
    {
        char firstLetter = word.charAt(0);
        return firstLetter >= 'A' && firstLetter <= 'Z';
    }

    @Override
    public boolean isSentenceEndingPunctuation(String word)
    {
        return word.equals(".") || word.equals("!") || word.equals("?");
    }

    @Override
    public ArrayList<String> getWordsThatCouldComeNext(String prevWord)
    {
        return nextWords.get(prevWord);
    }

    @Override
    public ArrayList<String> getAllWordsThatStartWithACapitalLetter()
    {
        return capitals;
    }

    @Override
    public int numberOfSentences()
    {
        int counter = 0;
        if (words.containsKey("."))
        {
            counter += words.get(".");
        }
        if (words.containsKey("?"))
        {
            counter += words.get("?");
        }
        if (words.containsKey("!"))
        {
            counter += words.get("!");
        }
        return counter;
    }

}
