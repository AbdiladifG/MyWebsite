package cp1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**********************************************************
 * Assignment: MTG
 *
 * Author: Abdiladif Gurhan
 *
 * Description: Second part of the Fractional Calculator
 *
 * Academic Integrity: I pledge that this program represents my own work. I
 * received help from my table members in designing and debugging my program.
 **********************************************************/
public class WordCounter implements TextAnalyzer
{

    private HashMap<String, Integer> words;

    public WordCounter(String filename)
    {
        FileReader file = null;
        words = new HashMap<String, Integer>();
        try
        {
            file = new FileReader(filename);
        }
        catch (FileNotFoundException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        Scanner fileScanner = new Scanner(file);
        while (fileScanner.hasNext())
        {
            // read next token use .next,
            // check to see if the token is already in the hashmap
            // if it is, increment count for token
            // else, add it to the hashmap with a count of 1
            String token = fileScanner.next();
            if (words.containsKey(token))
            {
                int count = words.get(token);
                count++;
                words.put(token, count);
            }
            else
            {
                words.put(token, 1);
            }

        }

    }

    @Override
    public int getWordCounts(String word)
    {
        return words.get(word);
    }

    @Override
    public boolean startsWithCapitalLetter(String word)
    {
        char firstLetter = word.charAt(0);
        return firstLetter >= 'A' && firstLetter <= 'Z';
    }

    @Override
    public boolean isSentenceEndingPunctuation(String word)
    {
        return word.equals(".") || word.equals("!") || word.equals("?");
    }

    @Override
    public ArrayList<String> getWordsThatCouldComeNext(String prevWord)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ArrayList<String> getAllWordsThatStartWithACapitalLetter()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int numberOfSentences()
    {
        // TODO Auto-generated method stub
        return 0;
    }

}
